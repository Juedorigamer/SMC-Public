# Reserved for Phase 5 — Textual TUI

This directory is an intentional placeholder for the future Textual-based TUI interface.

Implementation begins in Phase 5. The `Presenter` protocol in `vaultbreaker/presentation/presenter.py`
is the abstraction layer that will allow the TUI to reuse 100% of `core/` and `vulns/` without
any modifications to those modules.
