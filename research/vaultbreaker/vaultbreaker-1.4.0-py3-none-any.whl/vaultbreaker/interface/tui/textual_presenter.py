from __future__ import annotations

from typing import TYPE_CHECKING

from vaultbreaker.core.models import Finding, ScanResult
from vaultbreaker.interface.tui.messages import (
    FindingDiscovered,
    ScanDone,
    ScanFailed,
    ScanStarted,
)

if TYPE_CHECKING:
    from textual.widget import Widget


class TextualPresenter:
    """Presenter that forwards scan events to Textual widgets via messages."""

    def __init__(self, widget: Widget) -> None:
        self._widget = widget

    def scan_started(self, target: str) -> None:
        self._widget.post_message(ScanStarted(target))

    def finding_discovered(self, finding: Finding) -> None:
        self._widget.post_message(FindingDiscovered(finding))

    def scan_completed(self, result: ScanResult) -> None:
        self._widget.post_message(ScanDone(result))

    def error(self, message: str) -> None:
        self._widget.post_message(ScanFailed(message))

    def protocol_response(self, name: str, data: object) -> None:
        pass

    def check_running(self, check_id: str) -> None:
        pass

    def check_result(self, check_id: str, count: int) -> None:
        pass
