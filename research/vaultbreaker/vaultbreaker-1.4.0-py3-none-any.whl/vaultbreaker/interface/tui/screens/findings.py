from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.events import Key
from textual.screen import Screen
from textual.widgets import Footer, Header, Input, Label, ListItem, ListView

from vaultbreaker.core.models import Finding
from vaultbreaker.interface.tui.widgets.finding_detail import FindingDetail
from vaultbreaker.interface.tui.widgets.severity_badge import sev_color

_SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}


class FindingItem(ListItem):
    def __init__(self, finding: Finding) -> None:
        self.finding = finding
        color = sev_color(finding.severity)
        label_text = f"[{color}]{finding.severity.value:<8}[/{color}] {finding.title[:48]}"
        super().__init__(Label(label_text))


class FindingsScreen(Screen):
    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("/", "focus_search", "Search", show=True),
    ]

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-layout"):
            with Vertical(id="findings-list-panel", classes="panel"):
                yield Input(placeholder="/ Search findings…", id="search-input")
                yield ListView(id="findings-list")
            with Vertical(id="finding-detail-panel"):
                yield FindingDetail(id="finding-detail")
        yield Footer()

    def on_mount(self) -> None:
        self._populate(filter_text="")

    def _populate(self, filter_text: str = "") -> None:
        result = getattr(self.app, "scan_result", None)
        list_view = self.query_one("#findings-list", ListView)
        list_view.clear()
        if result is None:
            list_view.append(ListItem(Label("[dim]No scan result — run a scan first.[/dim]")))
            return
        findings = sorted(result.findings, key=lambda f: _SEV_ORDER.get(f.severity.value, 99))
        query = filter_text.lower()
        for finding in findings:
            if query and query not in finding.title.lower() and query not in finding.description.lower():
                continue
            list_view.append(FindingItem(finding))

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if isinstance(event.item, FindingItem):
            self.query_one(FindingDetail).show_finding(event.item.finding)

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "search-input":
            self._populate(filter_text=event.value)

    def action_cursor_down(self) -> None:
        self.query_one("#findings-list", ListView).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#findings-list", ListView).action_cursor_up()

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            self.app.pop_screen()

    def action_focus_search(self) -> None:
        self.query_one("#search-input", Input).focus()
