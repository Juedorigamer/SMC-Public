from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer
from textual.events import Key
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, Input, Label, Static

_CONFIG_DIR = Path.home() / ".vaultbreaker"
_CONFIG_FILE = _CONFIG_DIR / "config.toml"


def _write_config(data: dict[str, str]) -> None:
    """Write config dict to TOML file (simple string-only TOML)."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [f'{k} = "{v}"' for k, v in data.items() if v]
    _CONFIG_FILE.write_text("\n".join(lines), encoding="utf-8")


class ConfigScreen(Screen):
    BINDINGS: list = []

    def compose(self) -> ComposeResult:
        yield Header()
        with ScrollableContainer(id="config-form"):
            yield Static("[bold #4f98a3]Configuration[/bold #4f98a3]", classes="config-title")
            yield Label("[dim]Ollama Model[/dim]", classes="config-label")
            yield Input(placeholder="qwen2.5:3b", id="ollama-model")
            yield Label("[dim]Ollama URL[/dim]", classes="config-label")
            yield Input(placeholder="http://localhost:11434", id="ollama-url")
            yield Label("[dim]Default Rate Limit (req/s)[/dim]", classes="config-label")
            yield Input(placeholder="2.0", id="rate-limit")
            yield Label("[dim]Allowlist Path[/dim]", classes="config-label")
            yield Input(placeholder="~/.vaultbreaker/allowlist.txt", id="allowlist-path")
            with Horizontal(id="config-buttons"):
                yield Button("Save", id="save-btn", variant="success")
                yield Button("Test Ollama", id="test-ollama-btn")
            yield Static("", id="config-status")
        yield Footer()

    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            self.app.pop_screen()

    def on_mount(self) -> None:
        self._load_settings()

    def _load_settings(self) -> None:
        try:
            from vaultbreaker.config import settings

            self.query_one("#ollama-model", Input).value = settings.ollama_model or "qwen2.5:3b"
            self.query_one("#ollama-url", Input).value = str(settings.ollama_url or "http://localhost:11434")
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "save-btn":
            self._save_config()
        elif event.button.id == "test-ollama-btn":
            self.run_worker(self._do_test_ollama(), name="test-ollama")

    def _save_config(self) -> None:
        try:
            _write_config({
                "ollama_model": self.query_one("#ollama-model", Input).value,
                "ollama_url": self.query_one("#ollama-url", Input).value,
                "rate_limit": self.query_one("#rate-limit", Input).value,
                "allowlist_path": self.query_one("#allowlist-path", Input).value,
            })
            self.query_one("#config-status", Static).update("[green] Saved → ~/.vaultbreaker/config.toml[/green]")
        except Exception as exc:
            self.query_one("#config-status", Static).update(f"[red]Error: Error: {exc}[/red]")

    async def _do_test_ollama(self) -> None:
        self.query_one("#config-status", Static).update("[yellow]Testing Ollama…[/yellow]")
        try:
            from vaultbreaker.ai.ollama_client import OllamaClient

            url = self.query_one("#ollama-url", Input).value or "http://localhost:11434"
            client = OllamaClient(base_url=url)
            model = await client.detect_model()
            self.query_one("#config-status", Static).update(
                f"[green] Ollama OK — model: {model}[/green]"
            )
        except Exception as exc:
            self.query_one("#config-status", Static).update(f"[red]Error: Ollama unavailable: {exc}[/red]")
