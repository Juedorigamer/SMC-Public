from __future__ import annotations

import contextlib

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Checkbox, Footer, Header, Input, Label, Static

from vaultbreaker.core.models import Severity
from vaultbreaker.interface.tui.messages import FindingDiscovered, ScanDone, ScanFailed
from vaultbreaker.interface.tui.widgets.findings_table import FindingsTable

_SEV_LIST = [s.value for s in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO)]
_SEV_COLORS = {
    "CRITICAL": "#f87171",
    "HIGH": "#fb923c",
    "MEDIUM": "#facc15",
    "LOW": "#93c5fd",
    "INFO": "#94a3b8",
}


class DashboardScreen(Screen):
    BINDINGS = [
        Binding("s", "start_scan", "Scan"),
        Binding("r", "export_report", "Report"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._finding_count = 0
        self._sev_counts: dict[str, int] = {s: 0 for s in _SEV_LIST}
        self._scanning = False

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-layout"):
            with Vertical(id="left-panel", classes="panel"):
                yield Static("[bold #4f98a3]VaultBreaker[/bold #4f98a3]", classes="panel-title")
                yield Label("[dim]Target host[:port][/dim]", classes="section-label")
                yield Input(placeholder="mc.example.com", id="target-input")
                yield Checkbox("Ethics confirm (active checks)", id="ethics-confirm")
                yield Checkbox("Disable AI enrichment", id="no-ai")
                yield Button("Scan", id="scan-btn")
                yield Static("[dim]idle[/dim]", id="scan-status")
                yield Label("[dim]Findings[/dim]", classes="section-label")
                with Vertical(id="sev-counters"):
                    for sev in _SEV_LIST:
                        color = _SEV_COLORS[sev]
                        yield Static(
                            f"[{color}]{sev:<8}[/{color}] 0",
                            id=f"count-{sev}",
                            classes="sev-counter",
                        )
            with Vertical(id="right-panel", classes="panel"):
                yield FindingsTable(id="findings-table")
        yield Footer()

    # ── Interactions ────────────────────────────────────────────────────────

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "scan-btn":
            self.action_start_scan()

    def action_start_scan(self) -> None:
        if self._scanning:
            return
        target = self.query_one("#target-input", Input).value.strip()
        if not target:
            self.query_one("#scan-status", Static).update("[red]Enter a target host[/red]")
            return
        self._begin_scan(target)

    def _begin_scan(self, target: str) -> None:
        self._scanning = True
        self._finding_count = 0
        self._sev_counts = {s: 0 for s in _SEV_LIST}

        self.query_one(FindingsTable).clear()
        for sev in _SEV_LIST:
            color = _SEV_COLORS[sev]
            self.query_one(f"#count-{sev}", Static).update(
                f"[{color}]{sev:<8}[/{color}] 0"
            )
        self.query_one("#scan-status", Static).update("[yellow]scanning...[/yellow]")
        self.query_one("#scan-btn", Button).disabled = True

        ethics = self.query_one("#ethics-confirm", Checkbox).value
        no_ai = self.query_one("#no-ai", Checkbox).value

        self.app.scan_result = None  # type: ignore[attr-defined]
        self.run_worker(
            self._do_scan(target, ethics=ethics, use_ai=not no_ai),
            exclusive=True,
            name="scan",
        )

    async def _do_scan(self, target: str, ethics: bool = False, use_ai: bool = True) -> None:
        from vaultbreaker.ethics.audit_log import log_scan_start
        from vaultbreaker.interface.cli.commands.scan import _run_scan
        from vaultbreaker.interface.tui.textual_presenter import TextualPresenter

        host = target
        port = 25565
        if ":" in target and not target.startswith("["):
            parts = target.rsplit(":", 1)
            with contextlib.suppress(ValueError):
                host, port = parts[0], int(parts[1])

        log_scan_start(host)
        presenter = TextualPresenter(self)

        try:
            result = await _run_scan(
                host, port, rate=2.0, use_ai=use_ai, active=ethics, presenter=presenter
            )
            self.app.scan_result = result  # type: ignore[attr-defined]
        except Exception as exc:
            self.post_message(ScanFailed(str(exc)))
        finally:
            self._scanning = False
            self.query_one("#scan-btn", Button).disabled = False

    # ── Message handlers (posted by TextualPresenter) ───────────────────────

    def on_finding_discovered(self, message: FindingDiscovered) -> None:
        finding = message.finding
        self._finding_count += 1
        sev = finding.severity.value
        self._sev_counts[sev] = self._sev_counts.get(sev, 0) + 1

        self.query_one(FindingsTable).add_finding(finding, self._finding_count)

        color = _SEV_COLORS.get(sev, "#94a3b8")
        count = self._sev_counts[sev]
        self.query_one(f"#count-{sev}", Static).update(
            f"[{color}]{sev:<8}[/{color}] {count}"
        )

    def on_scan_done(self, message: ScanDone) -> None:
        result = message.result
        total = len(result.findings)
        self.query_one("#scan-status", Static).update(
            f"[green]Done — {total} finding(s)[/green]"
        )
        # Rebuild table so AI-enriched scores are visible
        table = self.query_one(FindingsTable)
        table.clear()
        for i, finding in enumerate(result.findings, 1):
            table.add_finding(finding, i)

    def on_scan_failed(self, message: ScanFailed) -> None:
        self.query_one("#scan-status", Static).update(f"[red]Error: {message.error}[/red]")

    # ── Report export ───────────────────────────────────────────────────────

    def action_export_report(self) -> None:
        result = getattr(self.app, "scan_result", None)
        if result is None:
            self.notify("No scan result — run a scan first.", severity="warning")
            return
        self.run_worker(self._show_report_modal(), name="report-modal")

    async def _show_report_modal(self) -> None:
        from vaultbreaker.interface.tui.app import ReportModal

        result = getattr(self.app, "scan_result", None)
        if result is None:
            return
        path = await self.app.push_screen_wait(ReportModal(result))
        if path:
            import webbrowser
            from pathlib import Path

            from vaultbreaker.reporting import ReportGenerator

            out = Path(path)
            ReportGenerator().save(result, out)
            self.notify(f"Report saved to {out.resolve()}", severity="information")
            webbrowser.open(out.resolve().as_uri())
