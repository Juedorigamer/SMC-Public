from __future__ import annotations

from textual.widgets import Static

from vaultbreaker.core.models import Severity

_SEV_COLORS: dict[str, str] = {
    "CRITICAL": "#f87171",
    "HIGH": "#fb923c",
    "MEDIUM": "#facc15",
    "LOW": "#93c5fd",
    "INFO": "#94a3b8",
}


def sev_color(severity: Severity | str) -> str:
    key = severity.value if isinstance(severity, Severity) else severity
    return _SEV_COLORS.get(key, "#94a3b8")


class SeverityBadge(Static):
    def __init__(self, severity: Severity, **kwargs: object) -> None:
        color = sev_color(severity)
        label = f"[{color}]● {severity.value}[/{color}]"
        super().__init__(label, **kwargs)
