from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static


class ScanProgress(Widget):
    def compose(self) -> ComposeResult:
        yield Static("[dim]idle[/dim]", id="progress-status")

    def set_status(self, text: str) -> None:
        self.query_one("#progress-status", Static).update(text)
