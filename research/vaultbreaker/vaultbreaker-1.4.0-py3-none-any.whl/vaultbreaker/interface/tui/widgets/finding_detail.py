from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static

from vaultbreaker.core.models import Finding
from vaultbreaker.interface.tui.widgets.severity_badge import sev_color


class FindingDetail(Widget):
    def compose(self) -> ComposeResult:
        yield Static("Select a finding to view details.", id="detail-title")
        yield Static("", id="detail-meta")
        yield Static("", id="detail-description")
        yield Static("", id="detail-remediation")
        yield Static("", id="detail-evidence")

    def show_finding(self, finding: Finding) -> None:
        color = sev_color(finding.severity)
        self.query_one("#detail-title", Static).update(
            f"[bold {color}]{finding.title}[/bold {color}]"
        )
        risk_str = f"{finding.ai_risk_score:.1f}/10" if finding.ai_risk_score is not None else "N/A"
        self.query_one("#detail-meta", Static).update(
            f"[dim]Severity:[/dim] [{color}]{finding.severity.value}[/{color}]  "
            f"[dim]Confidence:[/dim] {finding.confidence.value}  "
            f"[dim]Check:[/dim] {finding.check_id}  "
            f"[dim]AI Risk:[/dim] {risk_str}"
        )
        self.query_one("#detail-description", Static).update(
            f"\n[bold]Description[/bold]\n{finding.description}"
        )
        remediation = finding.ai_remediation or finding.remediation
        if remediation:
            self.query_one("#detail-remediation", Static).update(
                f"\n[bold]Remediation[/bold]\n{remediation}"
            )
        else:
            self.query_one("#detail-remediation", Static).update("")
        if finding.evidence:
            self.query_one("#detail-evidence", Static).update(
                f"\n[bold]Evidence[/bold]\n[dim]{finding.evidence}[/dim]"
            )
        else:
            self.query_one("#detail-evidence", Static).update("")
