from __future__ import annotations

from rich.text import Text
from textual.widgets import DataTable

from vaultbreaker.core.models import Finding
from vaultbreaker.interface.tui.widgets.severity_badge import sev_color

_COL_KEYS = ("#", "Severity", "Title", "Category", "Confidence", "AI Risk")


class FindingsTable(DataTable):
    def on_mount(self) -> None:
        self.add_column("#", width=4, key="num")
        self.add_column("Severity", width=10, key="sev")
        self.add_column("Title", width=42, key="title")
        self.add_column("Category", width=18, key="cat")
        self.add_column("Confidence", width=14, key="conf")
        self.add_column("AI Risk", width=8, key="risk")
        self.cursor_type = "row"

    def add_finding(self, finding: Finding, index: int) -> None:
        color = sev_color(finding.severity)
        sev_text = Text(finding.severity.value, style=color)
        risk = f"{finding.ai_risk_score:.1f}" if finding.ai_risk_score is not None else "-"
        self.add_row(
            str(index),
            sev_text,
            finding.title[:40],
            finding.check_id,
            finding.confidence.value.lower(),
            risk,
        )

    def on_data_table_header_selected(self, event: DataTable.HeaderSelected) -> None:
        self.sort(event.column_key)
