from __future__ import annotations

from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label

from vaultbreaker.core.models import ScanResult
from vaultbreaker.interface.tui.screens.config import ConfigScreen
from vaultbreaker.interface.tui.screens.dashboard import DashboardScreen
from vaultbreaker.interface.tui.screens.findings import FindingsScreen


class QuitModal(ModalScreen[bool]):
    def compose(self) -> ComposeResult:
        with __import__("textual.containers", fromlist=["Container"]).Container(id="quit-dialog"):
            yield Label("Quit VaultBreaker?")
            with Horizontal(id="quit-buttons"):
                yield Button("Yes", id="quit-yes", variant="error")
                yield Button("No", id="quit-no", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "quit-yes")

    def on_key(self, event: object) -> None:
        from textual.events import Key
        if isinstance(event, Key) and event.key == "escape":
            self.dismiss(False)


class ReportModal(ModalScreen[str | None]):
    def __init__(self, result: ScanResult) -> None:
        super().__init__()
        self._result = result

    def compose(self) -> ComposeResult:
        with __import__("textual.containers", fromlist=["Container"]).Container(id="report-dialog"):
            yield Label("Save report as:")
            yield Input(placeholder="report.html", id="report-path", value="report.html")
            with Horizontal(id="report-buttons"):
                yield Button("Save", id="report-save", variant="success")
                yield Button("Cancel", id="report-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "report-save":
            path = self.query_one("#report-path", Input).value or "report.html"
            self.dismiss(path)
        else:
            self.dismiss(None)

    def on_key(self, event: object) -> None:
        from textual.events import Key
        if isinstance(event, Key) and event.key == "escape":
            self.dismiss(None)


class VaultBreakerApp(App[None]):
    CSS_PATH = Path(__file__).parent / "vaultbreaker.tcss"
    TITLE = "VaultBreaker"
    SUB_TITLE = "Minecraft Security Scanner"

    BINDINGS = [
        Binding("q", "quit_app", "Quit"),
        Binding("f", "show_findings", "Findings"),
        Binding("c", "show_config", "Config"),
    ]

    scan_result: ScanResult | None = None

    def on_mount(self) -> None:
        self.push_screen(DashboardScreen())

    def action_quit_app(self) -> None:
        self.run_worker(self._do_quit_confirm(), exclusive=True, name="quit-confirm")

    async def _do_quit_confirm(self) -> None:
        confirmed = await self.push_screen_wait(QuitModal())
        if confirmed:
            self.exit()

    def action_show_findings(self) -> None:
        self.push_screen(FindingsScreen())

    def action_show_config(self) -> None:
        self.push_screen(ConfigScreen())


def run() -> None:
    VaultBreakerApp().run()
