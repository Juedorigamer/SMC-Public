from __future__ import annotations

from textual.message import Message

from vaultbreaker.core.models import Finding, ScanResult


class FindingDiscovered(Message):
    def __init__(self, finding: Finding) -> None:
        super().__init__()
        self.finding = finding


class ScanDone(Message):
    def __init__(self, result: ScanResult) -> None:
        super().__init__()
        self.result = result


class ScanFailed(Message):
    def __init__(self, error: str) -> None:
        super().__init__()
        self.error = error


class ScanStarted(Message):
    def __init__(self, target: str) -> None:
        super().__init__()
        self.target = target
