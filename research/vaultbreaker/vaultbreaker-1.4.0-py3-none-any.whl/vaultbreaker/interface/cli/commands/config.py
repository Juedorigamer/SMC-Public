from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from vaultbreaker.config import KNOWN_KEYS, _load_toml, _write_toml, get_config_path, load_with_sources

config_app = typer.Typer(name="config", help="Manage user configuration.", no_args_is_help=True)

console = Console()

_SOURCE_COLORS: dict[str, str] = {
    "env": "green",
    "toml": "cyan",
    "default": "dim",
    "flag": "yellow",
}


@config_app.command("show")
def show() -> None:
    """Print all config keys, their current values, and their source.

    Sources: env (environment variable) | toml (config file) | default (built-in).
    """
    data = load_with_sources()
    table = Table(title="VaultBreaker Configuration", expand=False)
    table.add_column("Key", style="bold")
    table.add_column("Value")
    table.add_column("Source")

    for key, (value, source) in sorted(data.items()):
        color = _SOURCE_COLORS.get(source, "white")
        table.add_row(key, str(value), f"[{color}]{source}[/{color}]")

    console.print(table)


@config_app.command("set")
def set_value(
    key: Annotated[str, typer.Argument(help="Config key to set")],
    value: Annotated[str, typer.Argument(help="Value to assign")],
) -> None:
    """Set a config value and persist it to the TOML file.

    Example:
      vaultbreaker config set ollama_model gemma3:4b
    """
    if key not in KNOWN_KEYS:
        known = ", ".join(sorted(KNOWN_KEYS.keys()))
        console.print(f"[red]Unknown key:[/red] [bold]{key}[/bold]")
        console.print(f"Known keys: {known}")
        raise typer.Exit(code=1)

    # Coerce the string value to the expected type
    target_type = KNOWN_KEYS[key]
    try:
        if target_type is bool:
            if value.lower() in ("true", "1", "yes"):
                coerced: object = True
            elif value.lower() in ("false", "0", "no"):
                coerced = False
            else:
                raise ValueError(f"Cannot parse bool from: {value!r}")
        else:
            coerced = target_type(value)
    except (ValueError, TypeError) as exc:
        console.print(f"[red]Invalid value for [bold]{key}[/bold]:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    current = _load_toml()
    current[key] = coerced
    _write_toml(current)

    path = get_config_path()
    console.print(f"[green]✓[/green] Set [bold]{key}[/bold] = [cyan]{coerced}[/cyan]")
    console.print(f"[dim]Saved to {path}[/dim]")


@config_app.command("path")
def path() -> None:
    """Print the absolute path to the config TOML file (whether or not it exists)."""
    config_path = get_config_path()
    console.print(str(config_path.resolve()))
