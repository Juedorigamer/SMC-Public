from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.table import Table

from vaultbreaker.core.models import Confidence, Finding, PingResult, ScanResult, Severity, Target
from vaultbreaker.core.ping import ping_server
from vaultbreaker.core.ports import KNOWN_PORTS, sweep_ports
from vaultbreaker.core.query import query_server
from vaultbreaker.core.ratelimit import TokenBucket
from vaultbreaker.core.resolver import resolve_host
from vaultbreaker.ethics.levels import EthicsLevel
from vaultbreaker.interface.cli.rich_presenter import RichPresenter
from vaultbreaker.vulns.registry import get_all_checks

console = Console()


def _validate_rate(value: float) -> float:
    if value < 0.1 or value > 20.0:
        raise typer.BadParameter("--rate debe estar entre 0.1 y 20.0")
    return value


def _validate_max_concurrent(value: int) -> int:
    if value < 1 or value > 16:
        raise typer.BadParameter("--max-concurrent debe estar entre 1 y 16")
    return value


def _port_finding(host: str, port: int) -> Finding:
    label = KNOWN_PORTS.get(port, "unknown service")
    return Finding(
        check_id="port-sweep",
        title=f"Port {port} open — {label} accessible",
        severity=Severity.INFO,
        confidence=Confidence.CONFIRMED,
        description=f"TCP port {port} ({label}) is reachable from the scanning host.",
        evidence=f"TCP connection to {host}:{port} succeeded",
    )


async def _enrich_with_ai(
    result: ScanResult,
    presenter: RichPresenter,
    *,
    ai_fast: bool = False,
) -> str | None:
    """Run AI enrichment on all findings. Returns executive summary or None."""
    from vaultbreaker.ai.ollama_client import OllamaClient, OllamaUnavailable
    from vaultbreaker.ai.remediation import generate_remediation
    from vaultbreaker.ai.risk_scorer import score_finding
    from vaultbreaker.ai.summary import generate_executive_summary
    from vaultbreaker.config import settings

    client = OllamaClient(base_url=settings.ollama_url)
    try:
        model = await client.detect_model()
    except OllamaUnavailable as exc:
        presenter.error(f"AI: Ollama unavailable — skipping enrichment ({exc})")
        return None

    mode = "fast (score+summary only)" if ai_fast else "full"
    console.print(f"[dim]AI enrichment [{mode}] via [cyan]{model}[/cyan]…[/dim]")

    for finding in result.findings:
        await score_finding(client, model, finding)
        if not ai_fast:
            await generate_remediation(client, model, finding)

    summary = await generate_executive_summary(client, model, result)
    return summary


async def _run_scan(
    host: str,
    port: int,
    rate: float,
    use_ai: bool,
    ai_fast: bool,
    ethics_level: EthicsLevel,
    max_concurrent: int = 4,
    verbose: bool = False,
    quiet: bool = False,
    presenter: Any = None,
) -> ScanResult:
    limiter = TokenBucket(rate=rate, capacity=max(rate, 1.0))

    _resolve = await resolve_host(host, port)
    resolved_host, resolved_port = _resolve  # __iter__ yields (host, port)
    target = Target(host=resolved_host, port=resolved_port)

    if presenter is None:
        presenter = RichPresenter(console, verbose=verbose, quiet=quiet)

    # Show SRV redirect hint before "Scanning …" so the user knows why the host changed
    if not quiet and getattr(_resolve, "srv_redirected", False):
        _orig = getattr(_resolve, "original_host", host)
        console.print(f"  [dim]SRV redirect: {_orig} \u2192 {resolved_host}:{resolved_port}[/dim]")

    presenter.scan_started(target.address)

    t0 = time.monotonic()
    result = ScanResult(target=target)

    # ── Phase 1: SLP ping + UDP query in parallel ─────────────────────────────
    await limiter.acquire()
    await limiter.acquire()

    tasks: list[Any] = [
        ping_server(resolved_host, resolved_port),
        query_server(resolved_host, resolved_port),
    ]

    # Run bedrock ping in parallel when at probe level or above
    bedrock_task: asyncio.Task[Any] | None = None
    if ethics_level != EthicsLevel.PASSIVE:
        from vaultbreaker.core.bedrock_ping import bedrock_ping
        bedrock_task = asyncio.ensure_future(bedrock_ping(resolved_host))

    ping_raw, query_raw = await asyncio.gather(*tasks, return_exceptions=True)
    result.ping = None if isinstance(ping_raw, BaseException) else ping_raw
    result.query = None if isinstance(query_raw, BaseException) else query_raw

    # ── Legacy ping fallback if modern SLP failed ────────────────────────────
    if result.ping is None or not result.ping.online:
        from vaultbreaker.core.legacy_ping import legacy_ping
        legacy_result = await legacy_ping(resolved_host, resolved_port)
        if legacy_result:
            result.ping = PingResult(
                online=True,
                motd=legacy_result["motd"],
                version_name=legacy_result.get("version"),
                protocol_version=legacy_result.get("protocol_version"),
                players_online=legacy_result.get("players_online"),
                players_max=legacy_result.get("players_max"),
            )
            result.metadata["legacy_protocol"] = True

    # ── Collect bedrock result ────────────────────────────────────────────────
    if bedrock_task is not None:
        try:
            bedrock_data = await asyncio.wait_for(asyncio.shield(bedrock_task), timeout=0.1)
        except (asyncio.TimeoutError, Exception):
            bedrock_data = None
        if bedrock_data is None:
            # Give it a bit more time if not done yet
            try:
                bedrock_data = await bedrock_task
            except Exception:
                bedrock_data = None
        if bedrock_data:
            result.metadata["bedrock"] = bedrock_data

    presenter.protocol_response("SLP Ping", result.ping.model_dump() if result.ping else {})
    presenter.protocol_response("UDP Query", result.query.model_dump() if result.query else {})

    # ── Phase 2: port sweep — respects ethics level ───────────────────────────
    if ethics_level == EthicsLevel.PASSIVE:
        ports_to_sweep: list[int] = []
    else:
        ports_to_sweep = [p for p in KNOWN_PORTS if p != resolved_port]

    open_ports = await sweep_ports(resolved_host, ports_to_sweep, level=str(ethics_level))

    if result.ping and result.ping.online:
        open_ports = [resolved_port] + open_ports

    for p in open_ports:
        f = _port_finding(resolved_host, p)
        result.findings.append(f)
        presenter.finding_discovered(f)

    # ── Phase 3: vulnerability checks — parallel with semaphore ──────────────
    from vaultbreaker.ethics.audit_log import log_check_error

    checks = get_all_checks(level=ethics_level)
    semaphore = asyncio.Semaphore(max_concurrent)

    async def run_check(check: Any) -> list[Finding]:
        async with semaphore:
            return await check.run(result)  # type: ignore[no-any-return]

    check_results = await asyncio.gather(
        *[run_check(c) for c in checks],
        return_exceptions=True,
    )

    for check, check_result in zip(checks, check_results):
        presenter.check_running(check.check_id)
        if isinstance(check_result, BaseException):
            result.errors.append(f"{check.check_id}: {check_result}")
            log_check_error(check.check_id, str(check_result))
        else:
            for f in check_result:
                result.findings.append(f)
                presenter.finding_discovered(f)
            presenter.check_result(check.check_id, len(check_result))

    # Sort findings by check_id for deterministic output across parallel runs
    result.findings.sort(key=lambda f: f.check_id)

    result.duration_s = time.monotonic() - t0

    if use_ai and result.findings:
        summary = await _enrich_with_ai(result, presenter, ai_fast=ai_fast)
        if summary:
            result.executive_summary = summary
            console.rule("[bold]AI Executive Summary[/bold]")
            console.print(summary)
            console.rule()

    presenter.scan_completed(result)
    return result


async def _run_batch(
    targets: list[str],
    default_port: int,
    rate: float,
    use_ai: bool,
    ai_fast: bool,
    ethics_level: EthicsLevel,
    max_concurrent: int,
    batch_semaphore: asyncio.Semaphore,
    verbose: bool,
    quiet: bool,
) -> list[ScanResult]:
    """Run scans over multiple targets with a global semaphore and Rich progress bar."""
    results: list[ScanResult] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        transient=True,
    ) as progress:
        task_id = progress.add_task("Scanning targets", total=len(targets))

        async def scan_one(i: int, raw_host: str) -> ScanResult | BaseException:
            host_port: int | None = None
            if ":" in raw_host and not raw_host.startswith("["):
                parts = raw_host.rsplit(":", 1)
                try:
                    host_port = int(parts[1])
                    raw_host = parts[0]
                except ValueError:
                    pass
            port = host_port if host_port is not None else default_port

            progress.update(task_id, description=f"Scanning {raw_host} ({i + 1}/{len(targets)})")
            async with batch_semaphore:
                null_presenter = _make_null_presenter()
                try:
                    return await _run_scan(
                        raw_host, port, rate, use_ai, ai_fast, ethics_level,
                        max_concurrent=max_concurrent, verbose=verbose, quiet=True,
                        presenter=null_presenter,
                    )
                except Exception as exc:
                    console.print(f"[red]Error scanning {raw_host}: {exc}[/red]")
                    return exc

        scan_tasks = [scan_one(i, h) for i, h in enumerate(targets)]
        raw_results = await asyncio.gather(*scan_tasks, return_exceptions=True)

        progress.update(task_id, completed=len(targets))

    for r in raw_results:
        if isinstance(r, ScanResult):
            results.append(r)

    return results


def _make_null_presenter() -> Any:
    from vaultbreaker.presentation.null_presenter import NullPresenter
    return NullPresenter()


def _print_batch_summary(results: list[ScanResult]) -> None:
    table = Table(title="Batch Scan Summary", show_lines=True)
    table.add_column("Host", style="cyan")
    table.add_column("Findings", justify="right")
    table.add_column("Highest Severity", justify="center")
    table.add_column("Duration", justify="right")

    sev_styles = {
        "CRITICAL": "bold red",
        "HIGH": "yellow",
        "MEDIUM": "blue",
        "LOW": "green",
        "INFO": "dim",
    }

    for result in results:
        findings = result.findings
        highest = "—"
        style = "dim"
        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
            if any(f.severity.value == sev for f in findings):
                highest = sev
                style = sev_styles.get(sev, "")
                break

        duration = f"{result.duration_s:.1f}s" if result.duration_s else "—"
        table.add_row(
            result.target.address,
            str(len(findings)),
            f"[{style}]{highest}[/{style}]",
            duration,
        )

    console.print(table)


def scan(
    target: Annotated[
        str | None,
        typer.Argument(help="Minecraft server host[:port] (optional when --input or --cidr is used)"),
    ] = None,
    port: Annotated[
        int | None,
        typer.Option("--port", "-p", help="Port override (takes precedence over host:port)"),
    ] = None,
    input_file: Annotated[
        Path | None,
        typer.Option("--input", help="File with one host[:port] per line (# comments supported)"),
    ] = None,
    cidr: Annotated[
        str | None,
        typer.Option("--cidr", help="CIDR range to scan (e.g. 192.168.1.0/24)"),
    ] = None,
    rate: Annotated[
        float,
        typer.Option("--rate", help="Requests per second (0.1–20.0)", callback=_validate_rate),
    ] = 2.0,
    no_ai: Annotated[bool, typer.Option("--no-ai", help="Skip AI enrichment")] = False,
    ai_fast: Annotated[
        bool,
        typer.Option(
            "--ai-fast",
            help="AI enrichment: risk scoring + summary only, skip per-finding remediation.",
        ),
    ] = False,
    max_concurrent: Annotated[
        int,
        typer.Option(
            "--max-concurrent",
            help="Max parallel vuln checks (1–16).",
            callback=_validate_max_concurrent,
        ),
    ] = 4,
    ethics_level: Annotated[
        EthicsLevel,
        typer.Option(
            "--ethics-level",
            help=(
                "Intrusion level: passive (fingerprint only), "
                "probe (port sweep + HTTP), active (+ RCON TCP probe)."
            ),
        ),
    ] = EthicsLevel.PROBE,
    ethics_confirm: Annotated[
        bool,
        typer.Option(
            "--ethics-confirm",
            help="[Deprecated] Alias for --ethics-level active.",
            hidden=True,
        ),
    ] = False,
    report: Annotated[
        str | None,
        typer.Option("--report", "-r", help="Save HTML report to this path (e.g. report.html)"),
    ] = None,
    report_aggregate: Annotated[
        bool,
        typer.Option("--report-aggregate", help="Generate an aggregate HTML index for multi-target scans"),
    ] = False,
    json_out: Annotated[
        str | None,
        typer.Option("--json", help="Save raw scan result as JSON to this path"),
    ] = None,
    no_allowlist: Annotated[
        bool,
        typer.Option("--no-allowlist", help="Skip allowlist check (use with caution)"),
    ] = False,
    verbose: Annotated[
        bool, typer.Option("--verbose", "-v", help="Show raw protocol responses and module debug info"),
    ] = False,
    quiet: Annotated[
        bool, typer.Option("--quiet", "-q", help="Suppress all output except findings and errors"),
    ] = False,
) -> None:
    """Scan a Minecraft server for vulnerabilities.

    Examples:

      vaultbreaker scan play.example.com

      vaultbreaker scan mc.example.com:25566 --ethics-level active --report out.html

      vaultbreaker scan 192.168.1.10 --port 25566 --no-ai --json result.json

      vaultbreaker scan --cidr 192.168.1.0/24 --report-aggregate

      vaultbreaker scan --input targets.txt --no-ai
    """
    # ── First-run ethics prompt ───────────────────────────────────────────────
    from vaultbreaker.ethics.first_run import prompt_first_run
    prompt_first_run()

    # ── Deprecated --ethics-confirm alias ────────────────────────────────────
    if ethics_confirm:
        console.print(
            "[yellow]--ethics-confirm está deprecado, usa --ethics-level active[/yellow]"
        )
        ethics_level = EthicsLevel.ACTIVE

    if ethics_level == EthicsLevel.ACTIVE:
        console.print(
            "[yellow]Active checks enabled.[/yellow] Ensure you have explicit "
            "permission to probe this server."
        )

    # ── --no-ai beats --ai-fast ───────────────────────────────────────────────
    if no_ai and ai_fast:
        console.print(
            "[yellow]Warning: --no-ai takes precedence over --ai-fast; AI disabled.[/yellow]"
        )
        ai_fast = False

    # ── Collect targets ───────────────────────────────────────────────────────
    from vaultbreaker.core.target_loader import load_targets

    host_list = [target] if target is not None else None

    try:
        all_targets = load_targets(
            hosts=host_list,
            input_file=input_file,
            cidr=cidr,
        )
    except typer.BadParameter as exc:
        raise typer.BadParameter(str(exc)) from exc

    import sys

    from vaultbreaker.ethics.audit_log import log_scan_start

    # ── Allowlist check ───────────────────────────────────────────────────────
    from vaultbreaker.ethics.allowlist import check_allowlist

    for t in all_targets:
        _t_host = t.rsplit(":", 1)[0] if (":" in t and not t.startswith("[")) else t
        check_allowlist(_t_host, no_allowlist=no_allowlist)

    # ── Single-target fast path ───────────────────────────────────────────────
    if len(all_targets) == 1:
        raw_host = all_targets[0]
        host_port: int | None = None
        if ":" in raw_host and not raw_host.startswith("["):
            parts = raw_host.rsplit(":", 1)
            try:
                host_port = int(parts[1])
                raw_host = parts[0]
            except ValueError:
                pass

        if port is not None and host_port is not None:
            console.print(
                f"[yellow]Warning: port in target ({host_port}) overridden by --port ({port})[/yellow]"
            )
            final_port = port
        elif port is not None:
            final_port = port
        elif host_port is not None:
            final_port = host_port
        else:
            final_port = 25565

        log_scan_start(raw_host, ethics_level=str(ethics_level), flags=sys.argv[1:])

        result = asyncio.run(
            _run_scan(
                raw_host,
                final_port,
                rate,
                use_ai=not no_ai,
                ai_fast=ai_fast,
                ethics_level=ethics_level,
                max_concurrent=max_concurrent,
                verbose=verbose,
                quiet=quiet,
            )
        )

        if result is None:
            return

        if json_out:
            from vaultbreaker.reporting import JsonReporter
            j = Path(json_out)
            JsonReporter().save(result, j)
            console.print(f"\n[green]\u2713 JSON saved \u2192[/green] [cyan]{j.resolve()}[/cyan]")

        if report:
            import webbrowser

            from vaultbreaker.reporting import ReportGenerator

            out = Path(report)
            ReportGenerator().save(result, out)
            console.print(f"\n[green]\u2713 Report saved \u2192[/green] [cyan]{out.resolve()}[/cyan]")
            webbrowser.open(out.resolve().as_uri())

        if report_aggregate:
            from vaultbreaker.reporting.report_generator import generate_aggregate_report
            index_path = generate_aggregate_report([result], Path.cwd())
            console.print(f"\n[green]\u2713 Aggregate report \u2192[/green] [cyan]{index_path}[/cyan]")

        return

    # ── Multi-target batch scan ───────────────────────────────────────────────
    console.print(f"[bold cyan]Batch scan:[/bold cyan] {len(all_targets)} targets")

    log_scan_start(
        f"batch:{len(all_targets)}", ethics_level=str(ethics_level), flags=sys.argv[1:]
    )

    default_port = port if port is not None else 25565
    batch_semaphore = asyncio.Semaphore(max_concurrent)

    batch_results = asyncio.run(
        _run_batch(
            all_targets,
            default_port,
            rate,
            use_ai=not no_ai,
            ai_fast=ai_fast,
            ethics_level=ethics_level,
            max_concurrent=max_concurrent,
            batch_semaphore=batch_semaphore,
            verbose=verbose,
            quiet=quiet,
        )
    )

    _print_batch_summary(batch_results)

    if report_aggregate:
        from vaultbreaker.reporting.report_generator import generate_aggregate_report
        index_path = generate_aggregate_report(batch_results, Path.cwd())
        console.print(f"\n[green]\u2713 Aggregate report \u2192[/green] [cyan]{index_path}[/cyan]")
        if report:
            import webbrowser
            webbrowser.open(index_path.resolve().as_uri())
    elif report and batch_results:
        # Save individual reports when --report is given without --report-aggregate
        from vaultbreaker.reporting import ReportGenerator
        for res in batch_results:
            slug = res.target.host.replace(":", "_").replace("/", "_")
            out = Path(report).parent / f"{slug}-{Path(report).name}"
            ReportGenerator().save(res, out)
            console.print(f"[green]\u2713 Report \u2192[/green] [cyan]{out.resolve()}[/cyan]")
