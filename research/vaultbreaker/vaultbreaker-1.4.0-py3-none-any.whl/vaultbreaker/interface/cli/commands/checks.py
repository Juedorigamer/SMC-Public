from __future__ import annotations

from rich.console import Console
from rich.table import Table

from vaultbreaker.vulns.registry import get_all_registered_checks

console = Console()

_KIND_STYLE = {
    "passive": "[green]passive[/green]",
    "probe": "[yellow]probe[/yellow]",
    "active": "[red]active[/red]",
}


def checks() -> None:
    """List all available vulnerability checks with their metadata.

    Examples:

      vaultbreaker checks

      vaultbreaker checks | grep active
    """
    table = Table(title="VaultBreaker — Vulnerability Checks", expand=False)
    table.add_column("ID", style="bold cyan", no_wrap=True)
    table.add_column("Severity", no_wrap=True)
    table.add_column("Kind", no_wrap=True)
    table.add_column("Description")

    for check in get_all_registered_checks():
        kind_display = _KIND_STYLE.get(check.kind, check.kind)
        table.add_row(
            check.check_id,
            check.title.split("(")[0].strip() if "(" in check.title else check.title,
            kind_display,
            check.description,
        )

    console.print(table)
