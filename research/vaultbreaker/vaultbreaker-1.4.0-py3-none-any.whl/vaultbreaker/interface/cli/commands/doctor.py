from __future__ import annotations

import asyncio
import sys

from rich.console import Console
from rich.table import Table

console = Console()


def _check(label: str, ok: bool, detail: str = "") -> tuple[str, str, str]:
    status = "[green]OK[/green]" if ok else "[red]FAIL[/red]"
    return label, status, detail


async def _ollama_checks(table: Table) -> None:
    from vaultbreaker.ai.ollama_client import OllamaClient, OllamaUnavailable
    from vaultbreaker.config import settings

    client = OllamaClient(base_url=settings.ollama_url, timeout=5.0)

    try:
        models = await client.list_models()
        table.add_row(*_check("Ollama reachable", True, settings.ollama_url))

        if not models:
            table.add_row(*_check("Ollama model", False, "No models — run: ollama pull qwen2.5:3b"))
        else:
            try:
                best = await client.detect_model()
                table.add_row(*_check("Ollama model", True, best))
            except OllamaUnavailable as exc:
                table.add_row(*_check("Ollama model", False, str(exc)))
    except OllamaUnavailable:
        table.add_row(*_check("Ollama reachable", False, f"not running at {settings.ollama_url}"))
        table.add_row(*_check("Ollama model", False, "skipped — Ollama unavailable"))


def _textual_check() -> tuple[str, str, str]:
    try:
        import textual
        detail = f"[green]installed[/green] ({textual.__version__})"
        return "TUI (textual)", "[green]OK[/green]", detail
    except ImportError:
        detail = "[yellow]missing[/yellow] — install with: pip install vaultbreaker[tui]"
        return "TUI (textual)", "[yellow]WARN[/yellow]", detail


def doctor() -> None:
    """Check environment dependencies and connectivity.

    Examples:

      vaultbreaker doctor
    """
    table = Table(title="VaultBreaker Environment Check", expand=False)
    table.add_column("Check", style="bold")
    table.add_column("Status", width=8)
    table.add_column("Detail")

    major, minor = sys.version_info[:2]
    py_ok = (major, minor) >= (3, 11)
    table.add_row(*_check("Python >=3.11", py_ok, f"{major}.{minor}.{sys.version_info.micro}"))

    for pkg, label, install in [
        ("mcstatus", "mcstatus", "pip install mcstatus"),
        ("rich", "rich", "pip install rich"),
        ("dns", "dnspython", "pip install dnspython"),
        ("httpx", "httpx", "pip install httpx"),
        ("jinja2", "jinja2", "pip install jinja2"),
        ("pydantic", "pydantic", "pip install pydantic"),
    ]:
        try:
            __import__(pkg)
            table.add_row(*_check(label, True, "installed"))
        except ImportError:
            table.add_row(*_check(label, False, install))

    table.add_row(*_textual_check())

    asyncio.run(_ollama_checks(table))

    console.print(table)
