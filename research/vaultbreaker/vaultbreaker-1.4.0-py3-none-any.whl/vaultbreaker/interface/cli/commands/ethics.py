from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.panel import Panel

console = Console()

_SUMMARY = """\
[bold]VaultBreaker — Ethical Use Policy[/bold]

1. [cyan]Purpose[/cyan]  Defensive security tool. Not an exploit kit or attack automator.

2. [cyan]Authorization[/cyan]  Only scan servers you own or have explicit written permission
   to test. Unauthorized scanning is illegal in most jurisdictions.

3. [cyan]Legal notice[/cyan]  Potential applicability: CFAA (US), CMA (UK), Convenio de
   Budapest, Código Penal art. 197 (ES/LATAM). You are solely responsible.

4. [cyan]Ethics levels[/cyan]
   • passive  — fingerprint via SLP ping/query only, no extra port sweep
   • probe    — full port sweep + HTTP probes (default)
   • active   — includes RCON TCP probe; requires explicit acknowledgment

5. [cyan]Responsible disclosure[/cyan]  Report findings to server operators within 90 days.
   See [dim]SECURITY.md[/dim] for coordinated disclosure process.

6. [cyan]Data handling[/cyan]  Audit log stays local (~/.vaultbreaker/audit.log).
   No telemetry. Ollama AI runs entirely on your machine.

7. [cyan]Misuse reporting[/cyan]  Contact antoniocifuentes2027@gmail.com
"""


def _find_ethics_md() -> Path | None:
    candidates = [
        Path(__file__).parents[6] / "ETHICS.md",
        Path(__file__).parents[5] / "ETHICS.md",
        Path(__file__).parents[4] / "ETHICS.md",
    ]
    for p in candidates:
        if p.exists():
            return p
    try:
        import importlib.resources as ir
        ref = ir.files("vaultbreaker") / "../../ETHICS.md"
        resolved = Path(str(ref)).resolve()
        if resolved.exists():
            return resolved
    except Exception:
        pass
    return None


def ethics() -> None:
    """Display VaultBreaker's ethical use policy summary.

    Examples:

      vaultbreaker ethics
    """
    console.print(Panel(_SUMMARY, title="VaultBreaker — Ethical Use Policy", border_style="cyan"))

    ethics_path = _find_ethics_md()
    if ethics_path:
        console.print(f"\n[dim]Full policy:[/dim] [cyan]{ethics_path.resolve()}[/cyan]")
    else:
        console.print("\n[dim]Full policy: ETHICS.md (not found in expected location)[/dim]")
