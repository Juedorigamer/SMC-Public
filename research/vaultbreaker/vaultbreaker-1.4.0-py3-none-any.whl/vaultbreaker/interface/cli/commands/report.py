from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

console = Console()

_FORMATS = ("html", "md")


def report(
    scan_json: Annotated[Path, typer.Argument(help="JSON file produced by a previous scan (--json flag)")],
    format: Annotated[str, typer.Option("--format", "-f", help="Output format: html or md")] = "html",
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output path (defaults to <scan_json stem>.html/md)"),
    ] = None,
    force: Annotated[bool, typer.Option("--force", help="Overwrite output without confirmation")] = False,
) -> None:
    """Render an HTML or Markdown report from a saved scan JSON file."""
    if format not in _FORMATS:
        console.print(f"[red]Unknown format {format!r}. Choose: {', '.join(_FORMATS)}[/red]")
        raise typer.Exit(1)

    if not scan_json.exists():
        console.print(f"[red]File not found: {scan_json}[/red]")
        raise typer.Exit(1)

    ext = ".html" if format == "html" else ".md"
    out_path = output or scan_json.with_suffix(ext)

    if out_path.exists() and not force:
        overwrite = typer.confirm(f"{out_path} already exists. Overwrite?", default=False)
        if not overwrite:
            console.print("[yellow]Aborted.[/yellow]")
            raise typer.Exit(0)

    from vaultbreaker.core.models import ScanResult

    try:
        data = json.loads(scan_json.read_text(encoding="utf-8"))
        scan_result = ScanResult.model_validate(data)
    except Exception as exc:
        console.print(f"[red]Failed to parse {scan_json}: {exc}[/red]")
        raise typer.Exit(1) from exc

    if format == "html":
        from vaultbreaker.reporting import ReportGenerator
        ReportGenerator().save(scan_result, out_path)
    else:
        from vaultbreaker.reporting import MarkdownReporter
        MarkdownReporter().save(scan_result, out_path)

    console.print(f"[green]\u2713 Report saved \u2192[/green] [cyan]{out_path.resolve()}[/cyan]")
