from __future__ import annotations


def tui() -> None:
    """Launch the interactive TUI (requires: pip install vaultbreaker[tui])."""
    try:
        from vaultbreaker.interface.tui.app import run
    except ImportError as exc:
        import typer

        typer.echo("TUI requires: pip install vaultbreaker[tui]", err=True)
        raise typer.Exit(code=1) from exc
    run()
