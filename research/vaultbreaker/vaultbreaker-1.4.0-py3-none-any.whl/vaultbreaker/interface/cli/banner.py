from __future__ import annotations

import os
import sys
import time

from rich.align import Align
from rich.console import Console
from rich.live import Live
from rich.text import Text

# Palette (matches TUI theme)
TEAL = "#4f98a3"
GRAY = "#94a3b8"
DIM = "dim"

# Citrus-slice ASCII art with diagonal lightning bolt
# ~11 lines × 43 chars — citrus segments + bolt box at center
# Slot 0: fill character  Slot 1: bolt content (11 chars wide)
_LOGO_TEMPLATE = """\
         ·───────────────────·
        ╱  {f}╲       │       ╱{f} ╲
       │  {f}{f}{f} ╲      │      ╱ {f}{f}{f} │
       │ {f}{f}{f}{f}{f} ╲─────┼─────╱ {f}{f}{f}{f}{f} │
       │ {f}{f}{f}{f}{f}  ╔═══════════╗  {f}{f}{f} │
       │ {f}{f}{f}{f}{f}  ║  {bolt}  ║  {f}{f}{f} │
       │ {f}{f}{f}{f}{f}  ╚═══════════╝  {f}{f}{f} │
       │ {f}{f}{f}{f}{f} ╱─────┼─────╲ {f}{f}{f}{f}{f} │
       │  {f}{f}{f} ╱      │      ╲ {f}{f}{f}  │
        ╲  {f}╱        │        ╲{f} ╱
         ·───────────────────·"""

# (fill_char, bolt_text, fill_style, bolt_style)
_FRAMES: list[tuple[str, str, str, str]] = [
    ("░", "  ↯ ↯ ↯  ", DIM, f"bold {TEAL}"),
    ("░", "  ↯  ↯   ", DIM, f"bold {TEAL}"),
    ("█", "  ↯ ↯ ↯  ", "white", f"bold {TEAL}"),
    ("▒", "  ↯ ↯ ↯  ", DIM, TEAL),
]

_LOGO_STATIC_FILL = "░"
_LOGO_STATIC_BOLT = "  ↯ ↯ ↯  "

# Version exposed for banner and menu
VERSION = "0.6.0"


def _make_logo_text(fill: str, bolt: str, fill_style: str, bolt_style: str) -> Text:
    """Build a Rich Text object for one animation frame."""
    raw = _LOGO_TEMPLATE.format(f=fill, bolt=bolt)
    text = Text()
    for line in raw.splitlines():
        # Segment each line: border chars stay dim, fills get fill_style,
        # bolt box and bolt chars get bolt_style.
        in_box = False
        for ch in line:
            if ch in "╔╗╚╝═║":
                text.append(ch, style=bolt_style)
                in_box = True
            elif in_box and ch not in "\n":
                text.append(ch, style=bolt_style)
            elif ch in (fill, "░", "▒", "█"):
                text.append(ch, style=fill_style)
            else:
                text.append(ch, style=DIM)
        text.append("\n")
    return text


def _logo_static() -> Text:
    return _make_logo_text(_LOGO_STATIC_FILL, _LOGO_STATIC_BOLT, DIM, f"bold {TEAL}")


def _should_animate() -> bool:
    return (
        sys.stdout.isatty()
        and not os.environ.get("NO_ANIMATE")
        and os.environ.get("TERM") != "dumb"
        and os.environ.get("CI") is None
    )


def animate_logo(console: Console) -> None:
    """Play spin animation (if interactive TTY), then show static logo."""
    if not _should_animate():
        print_static_logo(console)
        return

    frame_texts = [
        Align.center(_make_logo_text(f, b, fs, bs))
        for f, b, fs, bs in _FRAMES
    ]

    with Live("", console=console, refresh_per_second=15, transient=True) as live:
        for _ in range(2):  # 2 full rotations = 8 frames
            for frame in frame_texts:
                live.update(frame)
                time.sleep(0.08)

    print_static_logo(console)


def print_static_logo(console: Console) -> None:
    """Print the static colored logo + subtitle."""
    console.print(Align.center(_logo_static()))
    console.print(
        Align.center(
            Text.assemble(
                ("VaultBreaker ", f"bold {TEAL}"),
                (f"v{VERSION}", GRAY),
                ("  —  ", DIM),
                ("Minecraft Security Scanner", DIM),
            )
        )
    )
    console.print()


# Legacy: kept so existing callers (main.py, tests) don't break
def print_banner(console: Console) -> None:
    print_static_logo(console)
