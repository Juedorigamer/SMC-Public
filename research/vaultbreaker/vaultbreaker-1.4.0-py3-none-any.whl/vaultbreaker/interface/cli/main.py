from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

from vaultbreaker.constants import VERSION
from vaultbreaker.interface.cli.banner import print_banner
from vaultbreaker.interface.cli.commands.checks import checks
from vaultbreaker.interface.cli.commands.config import config_app
from vaultbreaker.interface.cli.commands.doctor import doctor
from vaultbreaker.interface.cli.commands.ethics import ethics
from vaultbreaker.interface.cli.commands.report import report
from vaultbreaker.interface.cli.commands.scan import scan
from vaultbreaker.interface.cli.commands.tui_cmd import tui

app = typer.Typer(
    name="vaultbreaker",
    help="Ethical Minecraft server vulnerability scanner.",
    no_args_is_help=False,   # We handle the no-arg case ourselves
    rich_markup_mode="rich",
)

app.command("scan")(scan)
app.command("doctor")(doctor)
app.command("report")(report)
app.command("tui")(tui)
app.command("checks")(checks)
app.command("ethics")(ethics)
app.add_typer(config_app, name="config")

_console = Console()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        bool,
        typer.Option("--version", "-V", help="Show version and exit.", is_eager=True),
    ] = False,
) -> None:
    if version:
        _console.print(f"vaultbreaker {VERSION}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        print_banner(_console)


if __name__ == "__main__":
    app()
