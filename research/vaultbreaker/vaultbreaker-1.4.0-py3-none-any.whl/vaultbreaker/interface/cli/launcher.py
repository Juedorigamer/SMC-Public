from __future__ import annotations

import contextlib
import sys
from pathlib import Path

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from vaultbreaker.interface.cli.banner import TEAL, print_static_logo

# Commands shown in the interactive menu — must stay in sync with main.py registrations.
MENU_ITEMS: list[tuple[str, str]] = [
    ("scan",   "Scan a target server"),
    ("tui",    "Launch terminal UI"),
    ("report", "Render a past scan"),
    ("doctor", "Check environment"),
    ("exit",   "Quit"),
]

_GRAY = "#94a3b8"
_DIM = "dim"

# Arrow / control keys returned by readchar on each platform
_KEY_UP    = ("\x1b[A", "\x00H", "\xe0H")   # ESC[A, Win console up
_KEY_DOWN  = ("\x1b[B", "\x00P", "\xe0P")   # ESC[B, Win console down
_KEY_ENTER = ("\r", "\n", "\x0d")
_KEY_QUIT  = ("q", "Q", "\x03", "\x1c")     # q, Ctrl-C, Ctrl-\


def _render_menu(idx: int) -> Panel:
    lines: list[Text] = []
    for i, (cmd, desc) in enumerate(MENU_ITEMS):
        if i == idx:
            line = Text.assemble(
                ("  ❯ ", f"bold {TEAL}"),
                (f"{cmd:<8}", f"bold {TEAL}"),
                (" — ", f"bold {TEAL}"),
                (desc, f"bold {TEAL}"),
            )
        else:
            line = Text.assemble(
                ("    ", _DIM),
                (f"{cmd:<8}", _GRAY),
                (" — ", _DIM),
                (desc, _DIM),
            )
        lines.append(line)

    body = Text("\n").join(lines)
    body.append("\n\n")
    body.append("  ↑↓ j/k navigate   Enter select   q quit", style=_DIM)

    return Panel(
        Align.left(body),
        border_style=TEAL,
        padding=(1, 2),
    )


def _read_key() -> str:
    """Read one key press, returning a string. Handles multi-byte escape sequences."""
    try:
        import readchar
        return readchar.readkey()
    except KeyboardInterrupt:
        return "\x03"


def _goodbye(console: Console) -> None:
    console.print(f"\n  [{TEAL}]Goodbye. Stay ethical.[/]\n")


def _run_scan_interactive(console: Console) -> None:
    from rich.prompt import Prompt
    console.print(f"\n  [{TEAL}]vaultbreaker scan <target> [options][/]\n")
    target = Prompt.ask(f"  [{TEAL}]Target[/] (host or host:port)")
    if not target.strip():
        return
    console.print()
    from vaultbreaker.interface.cli.commands.scan import scan
    console.print(f"  [dim](AI enrichment disabled in interactive mode — use [bold]vaultbreaker scan --help[/bold] for full options)[/dim]")
    scan(
        target=target.strip(),
        port=25565,
        rate=2.0,
        no_ai=True,
        ethics_confirm=False,
        report=None,
        json_out=None,
        verbose=False,
        quiet=False,
    )


def _run_report_interactive(console: Console) -> None:
    from rich.prompt import Prompt
    console.print(f"\n  [{TEAL}]vaultbreaker report <scan.json>[/]\n")
    json_path = Prompt.ask(f"  [{TEAL}]JSON scan file[/]")
    if not json_path.strip():
        return
    from vaultbreaker.interface.cli.commands.report import report
    report(scan_json=Path(json_path.strip()))


def _execute(name: str, console: Console) -> None:
    if name == "exit":
        _goodbye(console)
        sys.exit(0)

    console.clear()
    print_static_logo(console)

    if name == "scan":
        _run_scan_interactive(console)
    elif name == "tui":
        from vaultbreaker.interface.cli.commands.tui_cmd import tui
        tui()
    elif name == "report":
        _run_report_interactive(console)
    elif name == "doctor":
        from vaultbreaker.interface.cli.commands.doctor import doctor
        doctor()

    # After command returns, pause so the user can read output
    if name not in ("tui",):
        console.print(f"\n  [{TEAL}]Press any key to return to menu…[/]")
        with contextlib.suppress(Exception):
            _read_key()


def run_launcher() -> None:
    """Show animated logo + interactive command menu. TTY-only."""
    from vaultbreaker.interface.cli.banner import animate_logo

    console = Console()
    animate_logo(console)

    idx = 0
    while True:
        console.clear()
        print_static_logo(console)
        console.print(_render_menu(idx))

        try:
            key = _read_key()
        except KeyboardInterrupt:
            key = "\x03"

        if key in _KEY_UP or key in ("k", "K"):
            idx = (idx - 1) % len(MENU_ITEMS)
        elif key in _KEY_DOWN or key in ("j", "J"):
            idx = (idx + 1) % len(MENU_ITEMS)
        elif key in _KEY_ENTER:
            cmd = MENU_ITEMS[idx][0]
            _execute(cmd, console)
            # After non-exit commands, redraw menu
        elif key in _KEY_QUIT:
            _goodbye(console)
            sys.exit(0)
