from __future__ import annotations

from rich.console import Console
from rich.live import Live
from rich.table import Table
from rich.text import Text

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

_SEV_MARKUP: dict[str, str] = {
    "CRITICAL": "red",
    "HIGH": "yellow",
    "MEDIUM": "blue",
    "LOW": "green",
    "INFO": "dim",
}


def severity_summary(findings: list[Finding]) -> str:
    """Return a Rich-markup severity count string, omitting zero-count levels.

    Example: "[red]2 CRITICAL[/red], [yellow]1 HIGH[/yellow]"
    """
    parts: list[str] = []
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        count = sum(1 for f in findings if f.severity.value == sev)
        if count > 0:
            color = _SEV_MARKUP[sev]
            parts.append(f"[{color}]{count} {sev}[/{color}]")
    return ", ".join(parts) if parts else "none"

_SEVERITY_COLORS: dict[str, str] = {
    "CRITICAL": "bold red",
    "HIGH": "red",
    "MEDIUM": "yellow",
    "LOW": "blue",
    "INFO": "dim",
}

_CONFIDENCE_LABELS: dict[str, str] = {
    Confidence.CONFIRMED: "",
    Confidence.LIKELY: " (likely)",
    Confidence.POSSIBLE: " (possible)",
    Confidence.FINGERPRINT_ONLY: " (fingerprint only)",
}


def _severity_text(finding: Finding) -> Text:
    color = _SEVERITY_COLORS.get(finding.severity.value, "white")
    qualifier = _CONFIDENCE_LABELS.get(finding.confidence, "")
    return Text(f"{finding.severity.value}{qualifier}", style=color)


class RichPresenter:
    def __init__(
        self,
        console: Console | None = None,
        *,
        verbose: bool = False,
        quiet: bool = False,
    ) -> None:
        self._console = console or Console()
        self._verbose = verbose
        self._quiet = quiet
        self._table: Table | None = None
        self._live: Live | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def scan_started(self, target: str) -> None:
        if self._quiet:
            return
        self._table = Table(title=f"Scan: {target}", expand=True)
        self._table.add_column("Severity / Confidence", width=26)
        self._table.add_column("Check ID", style="dim", width=22)
        self._table.add_column("Title")
        self._table.add_column("Evidence")
        self._live = Live(self._table, console=self._console, refresh_per_second=4)
        self._live.start()
        self._console.print(f"[bold green]>[/bold green] Scanning [cyan]{target}[/cyan]\u2026")

    def finding_discovered(self, finding: Finding) -> None:
        if self._quiet:
            sev_color = _SEVERITY_COLORS.get(finding.severity.value, "white")
            self._console.print(
                f"[{sev_color}]{finding.severity.value:<8}[/{sev_color}] {finding.title}"
            )
            return
        if self._table is None:
            return
        self._table.add_row(
            _severity_text(finding),
            finding.check_id,
            finding.title,
            (finding.evidence or "")[:80],
        )

    def scan_completed(self, result: ScanResult) -> None:
        if self._live:
            self._live.stop()

        port_inventory = [
            f for f in result.findings
            if f.check_id == "port-sweep" and f.severity == Severity.INFO
        ]
        security_findings = [f for f in result.findings if f not in port_inventory]

        self._console.print(
            f"\n[bold]Scan complete[/bold]: [bold]{len(security_findings)}[/bold] "
            f"security finding(s) ({severity_summary(security_findings)})"
        )
        if port_inventory:
            self._console.print(
                f"               [dim]+ {len(port_inventory)} port inventory entries[/dim]"
            )
        if result.duration_s is not None:
            self._console.print(f"[dim]Duration: {result.duration_s:.2f}s[/dim]")

    def error(self, message: str) -> None:
        if self._live:
            self._live.stop()
        self._console.print(f"[bold red]ERROR:[/bold red] {message}")

    # ── Verbose-only helpers ───────────────────────────────────────────────────

    def protocol_response(self, name: str, data: object) -> None:
        if not self._verbose:
            return
        import json as _json
        self._console.print(f"[dim]\u2502 [bold]{name}[/bold] raw response:[/dim]")
        try:
            text = _json.dumps(data, indent=2, default=str)
        except Exception:
            text = str(data)
        for line in text.splitlines():
            self._console.print(f"[dim]\u2502   {line}[/dim]")

    def check_running(self, check_id: str) -> None:
        if not self._verbose:
            return
        self._console.print(f"[dim]\u25b6 Running check: [cyan]{check_id}[/cyan][/dim]")

    def check_result(self, check_id: str, count: int) -> None:
        if not self._verbose:
            return
        self._console.print(f"[dim]\u2514 {check_id}: {count} finding(s)[/dim]")
