from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field
from pydantic import ConfigDict


class Severity(StrEnum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class Confidence(StrEnum):
    CONFIRMED = "CONFIRMED"          # active probe or unambiguous evidence
    LIKELY = "LIKELY"                # strong passive signal, high FP rate is low
    POSSIBLE = "POSSIBLE"            # partial evidence; alternative explanations exist
    FINGERPRINT_ONLY = "FINGERPRINT_ONLY"  # version/banner only; may be patched


class Target(BaseModel):
    host: str
    port: int = 25565
    label: str | None = None

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"


class PingResult(BaseModel):
    online: bool
    motd: str | None = None
    version_name: str | None = None
    protocol_version: int | None = None
    players_online: int | None = None
    players_max: int | None = None
    latency_ms: float | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class QueryResult(BaseModel):
    online: bool
    plugins: list[str] = Field(default_factory=list)
    map_name: str | None = None
    game_type: str | None = None
    host_ip: str | None = None
    host_port: int | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class Finding(BaseModel):
    check_id: str
    title: str
    severity: Severity
    confidence: Confidence = Confidence.CONFIRMED
    description: str
    evidence: str | None = None
    remediation: str | None = None
    ai_risk_score: float | None = None
    ai_remediation: str | None = None

    @property
    def severity_order(self) -> int:
        return {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}[self.severity.value]


class ScanResult(BaseModel):
    target: Target
    scanned_at: datetime = Field(default_factory=datetime.utcnow)
    ping: PingResult | None = None
    query: QueryResult | None = None
    findings: list[Finding] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    duration_s: float | None = None
    executive_summary: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def findings_by_severity(self) -> list[Finding]:
        return sorted(self.findings, key=lambda f: f.severity_order)

    @property
    def has_critical(self) -> bool:
        return any(f.severity == Severity.CRITICAL for f in self.findings)
