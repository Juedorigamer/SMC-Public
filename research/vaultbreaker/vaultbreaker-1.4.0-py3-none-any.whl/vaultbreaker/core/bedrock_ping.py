from __future__ import annotations

import asyncio
import os
import socket
import struct
from typing import Any

_RAKNET_MAGIC = b"\x00\xff\xff\x00\xfe\xfe\xfe\xfe\xfd\xfd\xfd\xfd\x12\x34\x56\x78"


async def bedrock_ping(host: str, port: int = 19132, timeout: float = 5.0) -> dict[str, Any] | None:
    """Ping a Bedrock/GeyserMC server via RakNet Unconnected Ping (UDP)."""
    loop = asyncio.get_event_loop()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setblocking(False)

    try:
        time_ms = int(loop.time() * 1000) & 0xFFFFFFFFFFFFFFFF
        client_guid = os.urandom(8)

        # Unconnected Ping: 0x01 + time (8 BE) + magic (16) + guid (8)
        packet = bytes([0x01]) + struct.pack(">Q", time_ms) + _RAKNET_MAGIC + client_guid

        await asyncio.wait_for(
            loop.sock_sendto(sock, packet, (host, port)),
            timeout=timeout,
        )

        data, _ = await asyncio.wait_for(
            loop.sock_recvfrom(sock, 4096),
            timeout=timeout,
        )

        return _parse_pong(data)
    except Exception:
        return None
    finally:
        sock.close()


def _parse_pong(data: bytes) -> dict[str, Any] | None:
    """Parse Unconnected Pong (0x1C)."""
    if not data or data[0] != 0x1C:
        return None

    # 1 (id) + 8 (time) + 8 (server_guid) + 16 (magic) = 33 bytes header
    offset = 33
    if len(data) < offset + 2:
        return None

    str_len = struct.unpack(">H", data[offset: offset + 2])[0]
    offset += 2

    if len(data) < offset + str_len:
        return None

    raw_str = data[offset: offset + str_len].decode("utf-8", errors="replace")

    # MCPE;{motd};{protocol};{version};{players};{max};{server_id};{sub_motd};{gamemode};...
    parts = raw_str.split(";")
    if len(parts) < 6:
        return None

    try:
        edition = parts[0]
        motd = parts[1]
        protocol_version = int(parts[2])
        version = parts[3]
        players_online = int(parts[4])
        players_max = int(parts[5])
        server_id = parts[6] if len(parts) > 6 else ""
        gamemode = parts[8] if len(parts) > 8 else ""
    except (ValueError, IndexError):
        return None

    return {
        "edition": edition,
        "motd": motd,
        "protocol_version": protocol_version,
        "version": version,
        "players_online": players_online,
        "players_max": players_max,
        "server_id": server_id,
        "gamemode": gamemode,
        "bedrock": True,
    }
