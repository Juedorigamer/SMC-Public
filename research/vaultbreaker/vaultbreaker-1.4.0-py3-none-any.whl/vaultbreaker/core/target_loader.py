from __future__ import annotations

import ipaddress
from pathlib import Path

import typer
from rich.console import Console

_console = Console()


def load_from_file(path: Path) -> list[str]:
    """Load hosts from a text file, ignoring blank lines and # comments."""
    targets: list[str] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            targets.append(line)
    return targets


def load_from_cidr(cidr: str) -> list[str]:
    """Expand CIDR to a list of usable IPv4 host strings."""
    try:
        network = ipaddress.ip_network(cidr, strict=False)
    except ValueError as exc:
        raise typer.BadParameter(f"CIDR inválido: {exc}") from exc

    targets: list[str] = []
    for addr in network.hosts():
        if isinstance(addr, ipaddress.IPv6Address):
            _console.print(f"[yellow]IPv6 no soportado aún, saltando {addr}[/yellow]")
            continue
        targets.append(str(addr))

    if len(targets) > 256:
        _console.print(
            f"[yellow]Warning: CIDR contiene {len(targets)} hosts. Esto puede tardar.[/yellow]"
        )

    return targets


def load_targets(
    hosts: list[str] | None = None,
    input_file: Path | None = None,
    cidr: str | None = None,
) -> list[str]:
    """Combine, deduplicate, and validate targets from all sources."""
    all_targets: list[str] = []

    if hosts:
        all_targets.extend(hosts)

    if input_file is not None:
        all_targets.extend(load_from_file(input_file))

    if cidr is not None:
        all_targets.extend(load_from_cidr(cidr))

    # Deduplicate preserving insertion order
    seen: set[str] = set()
    unique: list[str] = []
    for t in all_targets:
        if t not in seen:
            seen.add(t)
            unique.append(t)

    if not unique:
        raise typer.BadParameter("No se especificaron targets")

    return unique
