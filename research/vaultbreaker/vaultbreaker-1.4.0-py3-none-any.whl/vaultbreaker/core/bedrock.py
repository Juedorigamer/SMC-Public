from __future__ import annotations

import asyncio
import contextlib
from typing import Any

from vaultbreaker.core.models import PingResult


async def ping_bedrock(host: str, port: int = 19132, timeout: float = 5.0) -> PingResult:
    try:
        from mcstatus import BedrockServer

        server = BedrockServer(host, port)
        status = await asyncio.get_event_loop().run_in_executor(
            None, lambda: server.status(tries=2)
        )

        raw: dict[str, Any] = {}
        with contextlib.suppress(AttributeError):
            raw = {
                "edition": status.version.brand,
                "map_name": getattr(status, "map_name", None),
                "game_mode": getattr(status, "gamemode", None),
            }

        return PingResult(
            online=True,
            motd=str(status.description),
            version_name=status.version.name,
            protocol_version=status.version.protocol,
            players_online=status.players.online,
            players_max=status.players.max,
            latency_ms=getattr(status, "latency", None),
            raw=raw,
        )
    except Exception as exc:
        return PingResult(online=False, raw={"error": str(exc)})
