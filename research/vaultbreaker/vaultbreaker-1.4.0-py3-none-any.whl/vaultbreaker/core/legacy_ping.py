from __future__ import annotations

import asyncio
import contextlib
import struct
from typing import Any


async def legacy_ping(host: str, port: int = 25565, timeout: float = 5.0) -> dict[str, Any] | None:
    """Ping pre-1.7 Minecraft servers.  Tries 1.6 → 1.4/1.5 → 1.3 in order."""
    result = await _ping_1_6(host, port, timeout)
    if result is not None:
        return result

    result = await _ping_1_4_1_5(host, port, timeout)
    if result is not None:
        return result

    return await _ping_1_3(host, port, timeout)


async def _send_recv(host: str, port: int, payload: bytes, timeout: float) -> bytes | None:
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        writer.write(payload)
        await writer.drain()
        data = await asyncio.wait_for(reader.read(4096), timeout=timeout)
        writer.close()
        with contextlib.suppress(Exception):
            await asyncio.wait_for(writer.wait_closed(), timeout=2.0)
        return data
    except Exception:
        return None


def _parse_kick_string(data: bytes) -> str | None:
    """Extract the UTF-16BE string from a 0xFF kick packet."""
    if not data or data[0] != 0xFF or len(data) < 3:
        return None
    length = struct.unpack(">H", data[1:3])[0]
    raw = data[3: 3 + length * 2]
    return raw.decode("utf-16-be", errors="replace")


def _parse_new_style(raw_str: str) -> dict[str, Any] | None:
    """Parse §1\x00 separated fields (1.4+ format)."""
    # Remove leading §1 header then split on null bytes
    s = raw_str
    if s.startswith("§1"):
        s = s[2:]
    if s.startswith("\x00"):
        s = s[1:]

    if "\x00" in s:
        parts = [p for p in s.split("\x00") if p]
    else:
        # Some servers use § as separator even in new-style responses
        parts = [p for p in s.split("§") if p and p != "1"]

    if len(parts) < 4:
        return None

    try:
        return {
            "protocol_version": int(parts[0]),
            "version": parts[1],
            "motd": parts[2],
            "players_online": int(parts[3]),
            "players_max": int(parts[4]) if len(parts) > 4 else 0,
            "legacy": True,
        }
    except (ValueError, IndexError):
        return None


def _parse_old_style(raw_str: str) -> dict[str, Any] | None:
    """Parse §-separated fields (1.3 format: motd§current§max)."""
    parts = raw_str.split("§")
    if len(parts) < 3:
        return None
    try:
        return {
            "protocol_version": 0,
            "version": "<=1.3",
            "motd": parts[0],
            "players_online": int(parts[1]),
            "players_max": int(parts[2]),
            "legacy": True,
        }
    except (ValueError, IndexError):
        return None


async def _ping_1_6(host: str, port: int, timeout: float) -> dict[str, Any] | None:
    """Send the 1.6 Ping (0xFE 0x01 0xFA MC|PingHost payload)."""
    host_encoded = host.encode("utf-16-be")
    host_char_len = len(host)

    # inner data: protocol_version byte + hostname java-string + port int
    inner = (
        bytes([74])  # protocol 74 = 1.6.4
        + struct.pack(">H", host_char_len)
        + host_encoded
        + struct.pack(">I", port)
    )

    channel = "MC|PingHost".encode("utf-16-be")
    channel_char_len = len("MC|PingHost")

    plugin_msg = (
        bytes([0xFA])
        + struct.pack(">H", channel_char_len)
        + channel
        + struct.pack(">H", len(inner))
        + inner
    )

    data = await _send_recv(host, port, bytes([0xFE, 0x01]) + plugin_msg, timeout)
    if data is None:
        return None

    raw_str = _parse_kick_string(data)
    if raw_str is None:
        return None

    return _parse_new_style(raw_str)


async def _ping_1_4_1_5(host: str, port: int, timeout: float) -> dict[str, Any] | None:
    """Send the 1.4/1.5 ping (0xFE 0x01)."""
    data = await _send_recv(host, port, bytes([0xFE, 0x01]), timeout)
    if data is None:
        return None

    raw_str = _parse_kick_string(data)
    if raw_str is None:
        return None

    return _parse_new_style(raw_str)


async def _ping_1_3(host: str, port: int, timeout: float) -> dict[str, Any] | None:
    """Send the 1.3 ping (0xFE only)."""
    data = await _send_recv(host, port, bytes([0xFE]), timeout)
    if data is None:
        return None

    raw_str = _parse_kick_string(data)
    if raw_str is None:
        return None

    # Try new-style first, fall back to old-style
    result = _parse_new_style(raw_str)
    if result is not None:
        return result
    return _parse_old_style(raw_str)
