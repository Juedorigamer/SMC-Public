from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Iterator


@dataclass
class ResolveResult:
    """Resolution result with SRV redirect metadata."""

    host: str
    port: int
    original_host: str = ""
    srv_redirected: bool = False
    srv_record: str | None = None

    def __iter__(self) -> Iterator[object]:
        """Yield (host, port) so existing `a, b = result` unpacking still works."""
        yield self.host
        yield self.port


async def resolve_srv(host: str) -> tuple[str, int] | None:
    """Resolve _minecraft._tcp SRV record. Returns (host, port) or None."""
    try:
        import dns.resolver

        loop = asyncio.get_event_loop()
        answers = await loop.run_in_executor(
            None,
            lambda: dns.resolver.resolve(f"_minecraft._tcp.{host}", "SRV"),
        )
        record = answers[0]
        resolved_host = str(record.target).rstrip(".")
        resolved_port = int(record.port)
        return resolved_host, resolved_port
    except Exception:
        return None


async def resolve_host(host: str, port: int = 25565) -> ResolveResult:
    """Resolve host via SRV first, then fall back to as-is.

    Returns a ResolveResult that also unpacks as (host, port) for backward
    compatibility with code that does ``resolved_host, resolved_port = result``.
    """
    srv = await resolve_srv(host)
    if srv:
        resolved_host, resolved_port = srv
        redirected = resolved_host.lower() != host.lower()
        return ResolveResult(
            host=resolved_host,
            port=resolved_port,
            original_host=host,
            srv_redirected=redirected,
            srv_record=f"_minecraft._tcp.{host}" if redirected else None,
        )
    return ResolveResult(
        host=host,
        port=port,
        original_host=host,
        srv_redirected=False,
        srv_record=None,
    )
