from __future__ import annotations

import asyncio
import contextlib
import struct
from typing import Any

from vaultbreaker.core.models import PingResult


async def ping_legacy(host: str, port: int = 25565, timeout: float = 5.0) -> PingResult:
    """Pre-1.7 legacy ping (protocol versions 1.4–1.6).

    Sends the 0xFE 0x01 ping packet and parses the 0xFF kick-packet response.
    Falls back to PingResult(online=False) on any error.
    """
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=timeout
        )
        try:
            writer.write(b"\xfe\x01")
            await writer.drain()
            data = await asyncio.wait_for(reader.read(512), timeout=timeout)
        finally:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

        if not data or data[0] != 0xFF:
            return PingResult(online=False, raw={"error": "not a legacy server"})

        # Response: 0xFF <len:u16> <utf-16-be payload>
        payload_len = struct.unpack(">H", data[1:3])[0]
        payload = data[3 : 3 + payload_len * 2].decode("utf-16-be", errors="replace")
        parts = payload.split("\x00")

        motd = parts[3] if len(parts) > 3 else payload
        version_name = parts[4] if len(parts) > 4 else None

        return PingResult(
            online=True,
            motd=motd,
            version_name=version_name,
            raw={"legacy": True, "raw_payload": payload},
        )
    except Exception as exc:
        return PingResult(online=False, raw={"error": str(exc)})


async def ping_server(host: str, port: int = 25565, timeout: float = 5.0) -> PingResult:
    try:
        from mcstatus import JavaServer

        server = JavaServer(host, port, timeout=timeout)
        status = await asyncio.wait_for(
            asyncio.get_running_loop().run_in_executor(None, server.status),
            timeout=timeout,
        )

        raw: dict[str, Any] = {}
        with contextlib.suppress(AttributeError):
            raw = status.raw

        return PingResult(
            online=True,
            motd=str(status.description),
            version_name=status.version.name,
            protocol_version=status.version.protocol,
            players_online=status.players.online,
            players_max=status.players.max,
            latency_ms=status.latency,
            raw=raw,
        )
    except Exception as exc:
        return PingResult(online=False, raw={"error": str(exc)})
