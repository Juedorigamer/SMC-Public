from __future__ import annotations

import asyncio

from vaultbreaker.core.models import QueryResult


async def query_server(host: str, port: int = 25565, timeout: float = 3.0) -> QueryResult:
    try:
        from mcstatus import JavaServer

        server = JavaServer(host, port, timeout=timeout)
        result = await asyncio.wait_for(
            asyncio.get_running_loop().run_in_executor(None, server.query),
            timeout=timeout,
        )

        plugins_raw = getattr(result.software, "plugins", []) or []

        return QueryResult(
            online=True,
            plugins=list(plugins_raw),
            map_name=getattr(result.map, "name", None) if hasattr(result, "map") else None,
            game_type=getattr(result, "game_type", None),
            host_ip=getattr(result, "host_ip", None),
            host_port=getattr(result, "host_port", None),
            raw=result.raw if hasattr(result, "raw") else {},
        )
    except Exception as exc:
        return QueryResult(online=False, raw={"error": str(exc)})
