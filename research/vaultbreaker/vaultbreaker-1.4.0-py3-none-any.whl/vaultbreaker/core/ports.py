from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Iterable

# Well-known ports in the Minecraft ecosystem with their human-readable labels.
KNOWN_PORTS: dict[int, str] = {
    25565: "Minecraft Java (main)",
    25575: "RCON — remote console",
    8123:  "Dynmap web interface",
    19132: "Bedrock Edition / GeyserMC",
    25566: "Minecraft Java (alternate)",
    25567: "Minecraft Java (alternate)",
    25568: "Minecraft Java (alternate)",
    25569: "Minecraft Java (alternate)",
    25570: "Minecraft Java (alternate)",
}

_DEFAULT_TIMEOUT = 3.0  # seconds per port


async def _probe(host: str, port: int, timeout: float) -> bool:
    """Return True if a TCP connection to host:port succeeds within timeout."""
    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        writer.close()
        with contextlib.suppress(Exception):
            await asyncio.wait_for(writer.wait_closed(), timeout=2.0)
        return True
    except (TimeoutError, OSError):
        return False


async def sweep_ports(
    host: str,
    ports: Iterable[int] | None = None,
    timeout: float = _DEFAULT_TIMEOUT,
    level: str = "probe",
) -> list[int]:
    """Probe each port concurrently and return the list of open ones.

    When *ports* is None the port list is derived from *level*:
    - ``passive`` → only port 25565
    - ``probe`` or ``active`` → all KNOWN_PORTS
    """
    if ports is not None:
        targets = list(ports)
    elif level == "passive":
        targets = [25565]
    else:
        targets = list(KNOWN_PORTS)

    results = await asyncio.gather(*(_probe(host, p, timeout) for p in targets))
    return [port for port, open_ in zip(targets, results, strict=True) if open_]
