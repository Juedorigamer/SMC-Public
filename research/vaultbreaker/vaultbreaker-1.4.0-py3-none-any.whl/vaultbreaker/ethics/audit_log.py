from __future__ import annotations

import hashlib
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

from vaultbreaker.constants import VERSION

_LOG_DIR = Path.home() / ".vaultbreaker"
_LOG_FILE = _LOG_DIR / "audit.log"


def log_check_error(check_id: str, error: str) -> None:
    """Append a check_error event to the audit log. Fails silently."""
    entry = {
        "timestamp": datetime.now(UTC).isoformat(),
        "event": "check_error",
        "check_id": check_id,
        "error": error,
    }
    try:
        _LOG_DIR.mkdir(parents=True, exist_ok=True)
        with _LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


def log_scan_start(
    target: str,
    *,
    ethics_level: str = "probe",
    flags: list[str] | None = None,
) -> None:
    """Append one JSON line to ~/.vaultbreaker/audit.log. Fails silently."""
    argv_flags = flags if flags is not None else sys.argv[1:]
    argv_str = " ".join(sys.argv)
    entry = {
        "timestamp": datetime.now(UTC).isoformat(),
        "target": target,
        "tool_version": VERSION,
        "ethics_level": ethics_level,
        "flags": argv_flags,
        "command_hash": hashlib.sha256(argv_str.encode()).hexdigest(),
        "os_user": os.getenv("USER") or os.getenv("USERNAME") or "unknown",
    }
    try:
        _LOG_DIR.mkdir(parents=True, exist_ok=True)
        with _LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass
