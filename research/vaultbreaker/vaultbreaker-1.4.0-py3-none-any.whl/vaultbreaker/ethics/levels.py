from __future__ import annotations

from enum import StrEnum


class EthicsLevel(StrEnum):
    PASSIVE = "passive"  # solo 25565, sin checks activos ni HTTP probes
    PROBE = "probe"      # KNOWN_PORTS completo + HTTP probes, sin RCON
    ACTIVE = "active"    # todo, requiere confirmación explícita


_ORDER = [EthicsLevel.PASSIVE, EthicsLevel.PROBE, EthicsLevel.ACTIVE]


def requires(action_level: EthicsLevel, current_level: EthicsLevel) -> bool:
    """Return True if current_level satisfies action_level requirement."""
    return _ORDER.index(current_level) >= _ORDER.index(action_level)
