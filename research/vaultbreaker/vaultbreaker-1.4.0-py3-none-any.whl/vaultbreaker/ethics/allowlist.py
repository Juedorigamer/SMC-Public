from __future__ import annotations

from pathlib import Path

import typer

ALLOWLIST_PATH = Path.home() / ".vaultbreaker" / "allowlist.txt"


def load_allowlist(path: Path = ALLOWLIST_PATH) -> set[str] | None:
    """Load the allowlist from *path*.

    Returns None when the file does not exist (allowlist feature disabled).
    Returns a set of allowed host strings when the file exists.
    Blank lines and lines starting with '#' are ignored.
    """
    if not path.exists():
        return None

    allowed: set[str] = set()
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            entry = line.strip()
            if not entry or entry.startswith("#"):
                continue
            allowed.add(entry)
    return allowed


def is_allowed(target: str, allowlist: set[str] | None) -> bool:
    """Return True when *target* is permitted by *allowlist*.

    When allowlist is None (feature disabled) every target is allowed.
    """
    if allowlist is None:
        return True
    return target in allowlist


def check_allowlist(target: str, no_allowlist: bool = False) -> None:
    """Abort if *target* is not in the allowlist, unless --no-allowlist is set.

    Loads the allowlist from the default path. Raises typer.Exit when the
    target is blocked so callers do not need to handle return values.
    """
    if no_allowlist:
        return

    allowlist = load_allowlist(ALLOWLIST_PATH)
    if not is_allowed(target, allowlist):
        typer.echo(
            f"[red]Target '{target}' no está en tu allowlist.[/red]\n"
            "Añádelo a ~/.vaultbreaker/allowlist.txt o usa --no-allowlist para omitir.",
            err=True,
        )
        raise typer.Exit(code=1)
