from __future__ import annotations

from pathlib import Path

import typer

_CONFIG_DIR = Path.home() / ".vaultbreaker"
ACCEPTED_FLAG = _CONFIG_DIR / "accepted.flag"

_PROMPT_TEXT = """\
[bold yellow]VaultBreaker — Aviso de uso ético[/bold yellow]

Esta herramienta realiza análisis de seguridad activos sobre servidores Minecraft.
Úsala SOLO en servidores que te pertenezcan o para los que tengas permiso explícito.
El uso no autorizado puede infringir la ley.

¿Aceptas los términos de uso ético? [y/N] \
"""


def has_accepted() -> bool:
    """Return True when the user has previously accepted the terms."""
    return ACCEPTED_FLAG.exists()


def mark_accepted() -> None:
    """Persist acceptance flag to disk."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    ACCEPTED_FLAG.touch()


def prompt_first_run() -> None:
    """If the user hasn't accepted yet, show the prompt.  Abort on refusal."""
    if has_accepted():
        return

    answer = typer.prompt(_PROMPT_TEXT, default="N", show_default=False)
    if answer.strip().lower() not in {"y", "yes", "s", "si", "sí"}:
        typer.echo("Operación cancelada.", err=True)
        raise typer.Exit(code=1)

    mark_accepted()
    typer.echo("[green]Términos aceptados. La flag se guarda en ~/.vaultbreaker/accepted.flag[/green]")
