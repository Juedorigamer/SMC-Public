from __future__ import annotations

import time

from vaultbreaker.core.models import ScanResult, Target
from vaultbreaker.core.ping import ping_server
from vaultbreaker.core.query import query_server
from vaultbreaker.core.ratelimit import TokenBucket
from vaultbreaker.core.resolver import resolve_host
from vaultbreaker.presentation.presenter import Presenter
from vaultbreaker.vulns.registry import get_all_checks


async def run_scan(
    host: str,
    port: int = 25565,
    presenter: Presenter | None = None,
    rate: float = 2.0,
) -> ScanResult:
    """Composition root — wires core, vulns, and presentation together."""
    from vaultbreaker.presentation.null_presenter import NullPresenter

    p: Presenter = presenter or NullPresenter()  # type: ignore[assignment]
    limiter = TokenBucket(rate=rate, capacity=rate)

    resolved_host, resolved_port = await resolve_host(host, port)
    target = Target(host=resolved_host, port=resolved_port)

    p.scan_started(target.address)
    t0 = time.monotonic()
    result = ScanResult(target=target)

    await limiter.acquire()
    result.ping = await ping_server(resolved_host, resolved_port)

    await limiter.acquire()
    result.query = await query_server(resolved_host, resolved_port)

    for check in get_all_checks():
        try:
            for finding in await check.run(result):
                result.findings.append(finding)
                p.finding_discovered(finding)
        except Exception as exc:
            result.errors.append(f"{check.check_id}: {exc}")

    result.duration_s = time.monotonic() - t0
    p.scan_completed(result)
    return result
