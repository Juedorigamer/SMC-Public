from __future__ import annotations

from dataclasses import dataclass

from vaultbreaker.core.models import Finding, ScanResult


@dataclass
class ScanStarted:
    target: str


@dataclass
class FindingDiscovered:
    finding: Finding


@dataclass
class ScanCompleted:
    result: ScanResult


@dataclass
class ScanError:
    message: str
