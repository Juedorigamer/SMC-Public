from __future__ import annotations

from vaultbreaker.core.models import Finding, ScanResult


class NullPresenter:
    """No-op presenter for tests and headless/batch mode."""

    def scan_started(self, target: str) -> None:
        pass

    def finding_discovered(self, finding: Finding) -> None:
        pass

    def scan_completed(self, result: ScanResult) -> None:
        pass

    def error(self, message: str) -> None:
        pass

    def protocol_response(self, name: str, data: object) -> None:
        pass

    def check_running(self, check_id: str) -> None:
        pass

    def check_result(self, check_id: str, count: int) -> None:
        pass
