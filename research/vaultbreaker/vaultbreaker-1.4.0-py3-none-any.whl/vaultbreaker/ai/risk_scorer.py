from __future__ import annotations

import json
import logging
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from vaultbreaker.ai.ollama_client import OllamaClient, OllamaUnavailable
from vaultbreaker.core.models import Finding

_logger = logging.getLogger(__name__)
_PROMPTS_DIR = Path(__file__).parent / "prompts"
_env = Environment(loader=FileSystemLoader(str(_PROMPTS_DIR)), autoescape=False)

_SIMPLE_FALLBACK = (
    "Return ONLY JSON: "
    '{{"score": <0-10>, "category": "Configuration Weakness", "rationale": "<reason>"}}'
    "\nFinding: {title}\nSeverity: {severity}\nJSON:"
)


def _render_prompt(finding: Finding) -> str:
    return _env.get_template("risk_score.j2").render(finding=finding)


def _parse_score(raw: str) -> tuple[float, str, str] | None:
    """Extract (score, category, rationale) from a raw LLM response string."""
    text = raw.strip()
    # Find the first JSON object in the response
    start = text.find("{")
    end = text.rfind("}") + 1
    if start == -1 or end == 0:
        return None
    try:
        data = json.loads(text[start:end])
        score = float(data["score"])
        score = max(0.0, min(10.0, score))
        return score, str(data.get("category", "Unknown")), str(data.get("rationale", ""))
    except (json.JSONDecodeError, KeyError, ValueError):
        return None


async def score_finding(client: OllamaClient, model: str, finding: Finding) -> Finding:
    """Enrich a Finding with AI risk score. Returns the mutated finding.

    On any Ollama error, ai_risk_score stays None — scan continues.
    """
    try:
        raw = await client.generate(model, _render_prompt(finding))
        parsed = _parse_score(raw)

        if parsed is None:
            # Retry with a simpler prompt
            fallback = _SIMPLE_FALLBACK.format(
                title=finding.title, severity=finding.severity.value
            )
            raw = await client.generate(model, fallback)
            parsed = _parse_score(raw)

        if parsed is not None:
            finding.ai_risk_score = parsed[0]
    except OllamaUnavailable:
        _logger.debug("Ollama unavailable — skipping risk score for %s", finding.check_id)

    return finding
