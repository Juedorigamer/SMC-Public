from __future__ import annotations

import logging
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from vaultbreaker.ai.ollama_client import OllamaClient, OllamaUnavailable
from vaultbreaker.core.models import Finding

_logger = logging.getLogger(__name__)
_PROMPTS_DIR = Path(__file__).parent / "prompts"
_env = Environment(loader=FileSystemLoader(str(_PROMPTS_DIR)), autoescape=False)


def _render_prompt(finding: Finding) -> str:
    return _env.get_template("remediation.j2").render(finding=finding)


async def generate_remediation(client: OllamaClient, model: str, finding: Finding) -> Finding:
    """Enrich a Finding with AI-generated remediation steps.

    On any Ollama error, ai_remediation stays None — scan continues.
    """
    try:
        raw = await client.generate(model, _render_prompt(finding))
        text = raw.strip()
        if text:
            finding.ai_remediation = text
    except OllamaUnavailable:
        _logger.debug("Ollama unavailable — skipping remediation for %s", finding.check_id)

    return finding
