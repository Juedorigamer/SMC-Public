from __future__ import annotations

import logging
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from vaultbreaker.ai.ollama_client import OllamaClient, OllamaUnavailable
from vaultbreaker.core.models import ScanResult

_logger = logging.getLogger(__name__)
_PROMPTS_DIR = Path(__file__).parent / "prompts"
_env = Environment(loader=FileSystemLoader(str(_PROMPTS_DIR)), autoescape=False)


def _render_prompt(result: ScanResult) -> str:
    return _env.get_template("summary.j2").render(result=result)


async def generate_executive_summary(
    client: OllamaClient, model: str, result: ScanResult
) -> str | None:
    """Generate a plain-language executive summary for the full scan.

    Returns the summary string, or None if Ollama is unavailable.
    """
    if not result.findings:
        return "No security findings were identified during this scan."
    try:
        raw = await client.generate(model, _render_prompt(result))
        return raw.strip() or None
    except OllamaUnavailable:
        _logger.debug("Ollama unavailable — skipping executive summary")
        return None
