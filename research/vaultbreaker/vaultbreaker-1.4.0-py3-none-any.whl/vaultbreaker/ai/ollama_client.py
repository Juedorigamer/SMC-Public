from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import Any

import httpx

_PREFERRED_MODELS = ["qwen2.5:3b", "gemma3:4b"]
_INSTRUCT_HINTS = ["instruct", "chat", "it"]


class OllamaUnavailable(Exception):
    """Raised when Ollama is not reachable or returns an unexpected error."""


class OllamaClient:
    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        timeout: float = 60.0,
        _transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._transport = _transport

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
            transport=self._transport,
        )

    async def generate(self, model: str, prompt: str) -> str:
        """Non-streaming generation. Returns the full response string."""
        payload: dict[str, Any] = {"model": model, "prompt": prompt, "stream": False}
        try:
            async with self._client() as client:
                resp = await client.post("/api/generate", json=payload)
                resp.raise_for_status()
                return str(resp.json().get("response", ""))
        except httpx.ConnectError as exc:
            raise OllamaUnavailable(f"Cannot connect to Ollama at {self._base_url}") from exc
        except httpx.TimeoutException as exc:
            raise OllamaUnavailable(f"Ollama timed out after {self._timeout}s") from exc
        except httpx.HTTPStatusError as exc:
            raise OllamaUnavailable(f"Ollama returned HTTP {exc.response.status_code}") from exc

    async def generate_stream(self, model: str, prompt: str) -> AsyncGenerator[str, None]:
        """Streaming generation. Yields response tokens as they arrive."""
        payload: dict[str, Any] = {"model": model, "prompt": prompt, "stream": True}
        try:
            async with self._client() as client, client.stream("POST", "/api/generate", json=payload) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line.strip():
                            continue
                        try:
                            chunk = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        token = chunk.get("response", "")
                        if token:
                            yield token
                        if chunk.get("done"):
                            return
        except httpx.ConnectError as exc:
            raise OllamaUnavailable(f"Cannot connect to Ollama at {self._base_url}") from exc
        except httpx.TimeoutException as exc:
            raise OllamaUnavailable(f"Ollama timed out after {self._timeout}s") from exc

    async def list_models(self) -> list[str]:
        """Return list of model names available in Ollama."""
        try:
            async with self._client() as client:
                resp = await client.get("/api/tags")
                resp.raise_for_status()
                data = resp.json()
                return [m["name"] for m in data.get("models", [])]
        except httpx.ConnectError as exc:
            raise OllamaUnavailable(f"Cannot connect to Ollama at {self._base_url}") from exc
        except httpx.TimeoutException as exc:
            raise OllamaUnavailable("Ollama timed out") from exc

    async def detect_model(self) -> str:
        """Return the best available model name.

        Preference: qwen2.5:3b → gemma3:4b → smallest instruct model → first available.
        Raises OllamaUnavailable if no models are found.
        """
        available = await self.list_models()
        if not available:
            raise OllamaUnavailable("No models found in Ollama. Run: ollama pull qwen2.5:3b")

        for preferred in _PREFERRED_MODELS:
            for name in available:
                if name == preferred or name.startswith(preferred.split(":")[0] + ":"):
                    return name

        instruct = [n for n in available if any(h in n.lower() for h in _INSTRUCT_HINTS)]
        if instruct:
            return min(instruct, key=len)

        return available[0]

    async def is_available(self) -> bool:
        """Return True if Ollama is reachable, False otherwise."""
        try:
            await self.list_models()
            return True
        except OllamaUnavailable:
            return False
