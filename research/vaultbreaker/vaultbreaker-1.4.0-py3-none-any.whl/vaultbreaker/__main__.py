from vaultbreaker.interface.cli.main import app

app()
