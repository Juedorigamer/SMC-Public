from __future__ import annotations

from vaultbreaker.ethics.levels import EthicsLevel
from vaultbreaker.vulns.base import VulnCheck
from vaultbreaker.vulns.bedrock_exposed import BedrockExposedCheck
from vaultbreaker.vulns.bungeecord import BungeeCordCheck
from vaultbreaker.vulns.cracked import CrackedCheck
from vaultbreaker.vulns.dynmap import DynmapCheck
from vaultbreaker.vulns.log4shell import Log4ShellCheck
from vaultbreaker.vulns.outdated_version import OutdatedVersionCheck
from vaultbreaker.vulns.plugin_cve import PluginCVECheck
from vaultbreaker.vulns.query_exposed import QueryExposedCheck
from vaultbreaker.vulns.rcon import RCONCheck

_ALL_CHECKS: list[VulnCheck] = [
    CrackedCheck(),
    QueryExposedCheck(),
    OutdatedVersionCheck(),
    DynmapCheck(),
    Log4ShellCheck(),
    PluginCVECheck(),
    BungeeCordCheck(),
    RCONCheck(),
    BedrockExposedCheck(),
]

_LEVEL_ORDER = [EthicsLevel.PASSIVE, EthicsLevel.PROBE, EthicsLevel.ACTIVE]

_KIND_MIN_LEVEL: dict[str, EthicsLevel] = {
    "passive": EthicsLevel.PASSIVE,
    "probe": EthicsLevel.PROBE,
    "active": EthicsLevel.ACTIVE,
}


def get_all_checks(*, level: EthicsLevel = EthicsLevel.PROBE) -> list[VulnCheck]:
    """Return checks allowed at the given ethics level."""
    current_idx = _LEVEL_ORDER.index(level)
    return [
        c for c in _ALL_CHECKS
        if _LEVEL_ORDER.index(_KIND_MIN_LEVEL.get(c.kind, EthicsLevel.ACTIVE)) <= current_idx
    ]


def get_all_registered_checks() -> list[VulnCheck]:
    """Return every check regardless of level (for display/listing)."""
    return list(_ALL_CHECKS)


def get_check_by_id(check_id: str) -> VulnCheck | None:
    return next((c for c in _ALL_CHECKS if c.check_id == check_id), None)
