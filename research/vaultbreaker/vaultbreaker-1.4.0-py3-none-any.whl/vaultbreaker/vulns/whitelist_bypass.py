from __future__ import annotations

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

# Versions known to be affected by whitelist bypass (CVE-2021-43608 and related).
# Servers below these thresholds with whitelist-mode indicators are flagged.
_BYPASS_PROTOCOL_RANGE = range(47, 340)  # 1.8–1.12.2 era (incomplete whitelist enforcement)

_BYPASS_MOTD_HINTS = [
    "whitelist",
    "white-list",
    "members only",
    "application",
]


class WhitelistBypassCheck:
    check_id = "whitelist-bypass"
    title = "Whitelist Bypass Pattern Detected"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        motd = (result.ping.motd or "").lower()
        protocol = result.ping.protocol_version or 0

        has_whitelist_hint = any(h in motd for h in _BYPASS_MOTD_HINTS)
        in_affected_range = protocol in _BYPASS_PROTOCOL_RANGE

        if not (has_whitelist_hint or in_affected_range):
            return []

        if not (has_whitelist_hint and in_affected_range):
            confidence = Confidence.POSSIBLE
            severity = Severity.LOW
        else:
            confidence = Confidence.LIKELY
            severity = Severity.MEDIUM

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=severity,
                confidence=confidence,
                description=(
                    "This server appears to use a whitelist and runs a protocol version "
                    "associated with incomplete whitelist enforcement. Older Spigot/Bukkit "
                    "builds (1.8–1.12.2) contained whitelist bypass vectors where a player "
                    "could join during the brief window between connection and whitelist check."
                ),
                evidence=(
                    f"Protocol: {result.ping.protocol_version} | "
                    f"MOTD hint: {has_whitelist_hint}"
                ),
                remediation=(
                    "Update to a current Paper/Purpur build. "
                    "Consider adding a login plugin (AuthMe) as a second factor. "
                    "Restrict network access to the server port at the firewall level."
                ),
            )
        ]
