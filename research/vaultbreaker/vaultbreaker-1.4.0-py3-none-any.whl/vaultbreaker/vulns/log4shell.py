from __future__ import annotations

import re

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

# Log4Shell (CVE-2021-44228) affected Minecraft Java servers because the server
# used log4j-core to log chat messages. Mojang released patched builds:
#   - 1.18.1 (protocol 757) — first release with log4j 2.17.x bundled
#   - Older versions received patched re-releases (same protocol version)
#
# We cannot reliably distinguish a patched 1.18.0 re-release from an original
# 1.18.0 build via protocol version alone, so we flag the range and note the
# uncertainty. Protocol 758+ (1.19+) uses a fully non-vulnerable log4j.
#
# Proxy exemptions:
#   - Velocity uses SLF4J/Logback, not Log4j → immune by design → skip entirely.
#   - BungeeCord/Waterfall also use Logback for their own logging, but they sit
#     in front of Paper/Spigot backends that may still be affected → keep the
#     finding with an explanatory disclaimer.

_PROTOCOL_1_18 = 757               # 1.18 and 1.18.1 share this protocol
_SAFE_PROTOCOL = 758               # 1.19+ → not affected

_VERSION_18_1_RE = re.compile(r"1\.18\.1")

_FINGERPRINT_DISCLAIMER = (
    " Based on version fingerprint only — server may be patched via "
    "'-Dlog4j2.formatMsgNoLookups=true' or manual log4j-core upgrade."
)

_PROXY_DISCLAIMER = (
    "\nNote: proxy software detected — Log4Shell primarily affects backend "
    "Paper/Spigot servers, not proxies. Verify whether backend servers are "
    "running a vulnerable Minecraft version."
)


def _has_velocity(result: ScanResult) -> bool:
    """Return True if a Velocity proxy was identified in this scan."""
    return any(
        f.check_id == "bungeecord" and "Velocity" in f.title
        for f in result.findings
    )


def _has_other_proxy(result: ScanResult) -> bool:
    """Return True if a non-Velocity proxy (BungeeCord/Waterfall) was identified."""
    return any(
        f.check_id == "bungeecord" and "Velocity" not in f.title
        for f in result.findings
    )


class Log4ShellCheck:
    check_id = "log4shell"
    kind = "passive"
    title = "Log4Shell (CVE-2021-44228) — Passive Fingerprint"
    description = "Fingerprints log4j vulnerability risk via protocol version (no exploit)"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        protocol = result.ping.protocol_version
        if protocol is None or protocol < 0:
            return []

        if protocol >= _SAFE_PROTOCOL:
            return []

        # Velocity uses SLF4J/Logback — immune to CVE-2021-44228 by design.
        if _has_velocity(result):
            return []

        version_name = result.ping.version_name or ""

        if protocol == _PROTOCOL_1_18:
            if _VERSION_18_1_RE.search(version_name):
                return []
            note = (
                "Server reports protocol 757 (1.18.x) but version string does not "
                "confirm '1.18.1'. If running unpatched 1.18, log4j-core 2.14.1 is "
                "bundled and CVE-2021-44228 applies. Verify the exact build."
                + _FINGERPRINT_DISCLAIMER
            )
        else:
            note = (
                f"Server is running Minecraft protocol {protocol} "
                f"({version_name or 'unknown version'}), which typically bundles "
                "log4j-core < 2.15.0. Any player could trigger JNDI injection via "
                "crafted chat messages (Log4Shell, CVE-2021-44228) on an unpatched build."
                + _FINGERPRINT_DISCLAIMER
            )

        # BungeeCord/Waterfall are themselves immune (Logback), but their
        # backends may not be — append a contextual note.
        if _has_other_proxy(result):
            note += _PROXY_DISCLAIMER

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=Severity.MEDIUM,
                confidence=Confidence.FINGERPRINT_ONLY,
                description=note,
                evidence=(
                    f"Protocol: {protocol} | Version: {version_name!r} | "
                    "Affected log4j range: 2.0-beta9 – 2.14.1"
                ),
                remediation=(
                    "Upgrade to Minecraft 1.18.1 or later (log4j 2.17.x bundled). "
                    "As a short-term mitigation on older versions, add "
                    "'-Dlog4j2.formatMsgNoLookups=true' to server JVM arguments "
                    "and update log4j-core manually. "
                    "See: https://nvd.nist.gov/vuln/detail/CVE-2021-44228"
                ),
            )
        ]
