from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Literal

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version
from pydantic import BaseModel, field_validator

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

_DB_PATH = Path(__file__).parent / "cve_db" / "plugins.json"
_COLOR_CODE_RE = re.compile(r"§[0-9a-fk-orA-FK-OR]")

_SEVERITY_MAP: dict[str, Severity] = {
    "CRITICAL": Severity.CRITICAL,
    "HIGH": Severity.HIGH,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}


class CveEntry(BaseModel):
    plugin: str
    affected_versions: str
    cve_id: str | None          # None = real risk, no CVE assigned; see note field
    severity: Literal["CRITICAL", "HIGH", "MEDIUM", "LOW"]
    description: str
    note: str | None = None     # required when cve_id is None
    references: list[str]

    @field_validator("cve_id")
    @classmethod
    def _valid_id(cls, v: str | None) -> str | None:
        if v is None:
            return None
        cve = re.match(r"^CVE-\d{4}-\d{4,}$", v)
        ghsa = re.match(r"^GHSA-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}$", v)
        if not cve and not ghsa:
            raise ValueError(f"Invalid CVE/GHSA id: {v!r}")
        return v

    @field_validator("references")
    @classmethod
    def _non_empty_refs(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("references must be non-empty")
        return v


@lru_cache(maxsize=1)
def _load_db() -> list[CveEntry]:
    raw = json.loads(_DB_PATH.read_text(encoding="utf-8"))
    entries: list[CveEntry] = []
    for i, item in enumerate(raw):
        try:
            entries.append(CveEntry.model_validate(item))
        except Exception as exc:
            raise ValueError(f"plugins.json entry #{i} is invalid: {exc}") from exc
    return entries


def _normalize(name: str) -> str:
    """Lowercase, strip non-alphanumeric for fuzzy plugin name matching."""
    return re.sub(r"[^a-z0-9]", "", name.lower())


def _parse_plugin_version(raw: str) -> tuple[str, str | None]:
    """Split 'EssentialsX 2.18.0' → ('EssentialsX', '2.18.0')."""
    parts = raw.strip().rsplit(" ", 1)
    if len(parts) == 2:
        name, ver = parts
        if re.match(r"^\d+[\.\d]*", ver):
            return name, ver
    return parts[0], None


def _version_affected(plugin_version: str, affected_versions: str) -> bool:
    """Return True if plugin_version satisfies the affected specifier."""
    if affected_versions == "*":
        return True
    try:
        v = Version(plugin_version)
        spec = SpecifierSet(affected_versions, prereleases=True)
        return v in spec
    except (InvalidVersion, InvalidSpecifier):
        return False


def _detect_plugins(result: ScanResult) -> list[tuple[str, str | None]]:
    """Return [(plugin_name, version_or_None)] from all available signals."""
    detected: list[tuple[str, str | None]] = []

    # Signal 1: Query protocol plugin list
    if result.query and result.query.online:
        for raw in result.query.plugins:
            detected.append(_parse_plugin_version(raw))

    # Signal 2: Server software fingerprinting via version string
    if result.ping and result.ping.online:
        version = (result.ping.version_name or "").lower()
        for marker, name in [
            ("paper", "Paper"),
            ("spigot", "Spigot"),
            ("purpur", "Purpur"),
            ("folia", "Folia"),
        ]:
            if marker in version:
                detected.append((name, None))

    return detected


def _finding_title(entry: CveEntry) -> str:
    if entry.cve_id:
        return f"{entry.plugin}: {entry.cve_id}"
    return f"{entry.plugin}: Undocumented Configuration Risk"


def _finding_evidence(plugin_name: str, version_note: str, entry: CveEntry) -> str:
    id_part = entry.cve_id or "no CVE assigned"
    return f"{plugin_name} {version_note} | {id_part}"


def _finding_remediation(entry: CveEntry) -> str:
    if entry.cve_id:
        return (
            f"Update {entry.plugin} to a version beyond {entry.affected_versions}. "
            f"See: {entry.references[0]}"
        )
    return (
        f"Review {entry.plugin} configuration and consider migrating to an actively "
        f"maintained alternative. See: {entry.references[0]}"
    )


class PluginCVECheck:
    check_id = "plugin-cve"
    kind = "passive"
    title = "Plugin CVE Fingerprint"
    description = "Crosses detected plugins against CVE database using version specifiers"

    async def run(self, result: ScanResult) -> list[Finding]:
        try:
            db = _load_db()
        except ValueError as exc:
            return [
                Finding(
                    check_id=self.check_id,
                    title="CVE Database Load Error",
                    severity=Severity.INFO,
                    description=str(exc),
                )
            ]

        # Exclude log4j entries — log4shell.py handles those
        plugin_db = [e for e in db if not e.plugin.lower().startswith("log4j")]

        detected = _detect_plugins(result)
        if not detected:
            return []

        findings: list[Finding] = []
        seen: set[str] = set()  # deduplicate (plugin, cve_id) pairs

        for plugin_name, plugin_version in detected:
            norm_detected = _normalize(plugin_name)

            for entry in plugin_db:
                norm_entry = _normalize(entry.plugin)
                if norm_entry != norm_detected:
                    continue

                # Dedup key: use cve_id when present, fall back to entry description hash
                dedup_key = f"{norm_detected}:{entry.cve_id or id(entry)}"
                if dedup_key in seen:
                    continue

                if plugin_version is None:
                    if entry.affected_versions != "*":
                        continue  # can't confirm without version
                    version_note = "version unknown"
                else:
                    if not _version_affected(plugin_version, entry.affected_versions):
                        continue
                    version_note = f"v{plugin_version} matches {entry.affected_versions}"

                # Entries without a CVE ID are documented risks, not confirmed vulns
                confidence = (
                    Confidence.FINGERPRINT_ONLY
                    if entry.cve_id is None
                    else Confidence.CONFIRMED
                )

                seen.add(dedup_key)
                description = entry.description
                if entry.note:
                    description += f" ({entry.note})"

                findings.append(
                    Finding(
                        check_id=self.check_id,
                        title=_finding_title(entry),
                        severity=_SEVERITY_MAP[entry.severity],
                        confidence=confidence,
                        description=description,
                        evidence=_finding_evidence(plugin_name, version_note, entry),
                        remediation=_finding_remediation(entry),
                    )
                )

        return findings
