from __future__ import annotations

from vaultbreaker.core.models import Finding, ScanResult, Severity


class CrackedCheck:
    check_id = "cracked-server"
    kind = "passive"
    title = "Cracked Server (online-mode=false)"
    description = "Detects offline-mode servers via MOTD keywords and protocol heuristics"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        protocol = result.ping.protocol_version
        if protocol is None:
            return []

        # Servers with online-mode=false accept any username/UUID.
        # We detect via the -1 protocol "magic" sent by some cracked launchers
        # or via MOTD markers common in cracked server software.
        motd = (result.ping.motd or "").lower()
        cracked_hints = ["cracked", "offline", "unlicensed", "pirate"]

        is_cracked = any(hint in motd for hint in cracked_hints)

        # Protocol version 127 is used by some cracked proxies
        if protocol == 127:
            is_cracked = True

        if not is_cracked:
            return []

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=Severity.HIGH,
                description=(
                    "The server appears to run with online-mode=false, allowing players "
                    "to join without a valid Mojang/Microsoft account. This disables "
                    "Mojang's authentication, enabling username spoofing and UUID hijacking."
                ),
                evidence=f"MOTD: {result.ping.motd!r} | Protocol: {protocol}",
                remediation=(
                    "Set online-mode=true in server.properties. "
                    "If using BungeeCord, enable bungeecord-forwarding and set "
                    "online-mode=true on the proxy."
                ),
            )
        ]
