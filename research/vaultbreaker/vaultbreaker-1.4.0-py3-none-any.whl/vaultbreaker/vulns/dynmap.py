from __future__ import annotations

import asyncio

import httpx

from vaultbreaker.core.models import Finding, ScanResult, Severity

DYNMAP_PORT = 8123
DYNMAP_PATHS = ["/", "/standalone/config.js", "/tiles/"]

_TIMEOUT = httpx.Timeout(connect=3.0, read=4.0, write=3.0, pool=3.0)


class DynmapCheck:
    check_id = "dynmap-exposed"
    kind = "probe"
    title = "Dynmap Web Interface Exposed (unauthenticated)"
    description = "HTTP GET probe to port 8123 to detect unauthenticated Dynmap interface"

    async def run(self, result: ScanResult) -> list[Finding]:
        # Skip entirely if the port sweep didn't find port 8123 open.
        port_open = any(
            f.check_id == "port-sweep" and f"Port {DYNMAP_PORT}" in f.title
            for f in result.findings
        )
        if not port_open:
            return []

        host = result.target.host
        base_url = f"http://{host}:{DYNMAP_PORT}"

        async with httpx.AsyncClient(timeout=_TIMEOUT, follow_redirects=True) as client:
            tasks = [self._probe(client, base_url, path) for path in DYNMAP_PATHS]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        for path, resp in zip(DYNMAP_PATHS, results):
            if isinstance(resp, Exception):
                continue
            if resp is not None:
                return [
                    Finding(
                        check_id=self.check_id,
                        title=self.title,
                        severity=Severity.MEDIUM,
                        description=(
                            "An unauthenticated Dynmap web interface is accessible. "
                            "Dynmap renders a live map of the server world, revealing "
                            "player locations, base coordinates, and internal server "
                            "topology to any visitor."
                        ),
                        evidence=f"HTTP 200 at {base_url}{path}",
                        remediation=(
                            "Enable Dynmap's built-in login protection or restrict "
                            "port 8123 at the firewall. Set 'login-enabled: true' "
                            "and 'allowurlauth: false' in dynmap's configuration.txt."
                        ),
                    )
                ]
        return []

    async def _probe(self, client: httpx.AsyncClient, base_url: str, path: str) -> str | None:
        try:
            resp = await client.get(f"{base_url}{path}")
            if resp.status_code == 200 and self._looks_like_dynmap(resp.text):
                return path
        except (httpx.ConnectError, httpx.TimeoutException, httpx.ReadError):
            pass
        return None

    @staticmethod
    def _looks_like_dynmap(body: str) -> bool:
        markers = ["dynmap", "Dynmap", "standalone/config.js", "DynMap"]
        return any(m in body for m in markers)
