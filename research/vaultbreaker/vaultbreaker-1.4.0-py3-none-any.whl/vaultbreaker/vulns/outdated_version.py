from __future__ import annotations

import re

from vaultbreaker.core.models import Finding, ScanResult, Severity

LATEST_STABLE_PROTOCOL = 770  # Minecraft 1.21.4
LATEST_STABLE_NAME = "1.21.4"

# Protocol versions known to be vulnerable to critical CVEs
CRITICALLY_VULNERABLE_PROTOCOLS: set[int] = {
    *range(0, 340),   # 1.12.2 and earlier
    *range(340, 755), # 1.17 and earlier
}

# Strip §X Minecraft color/format codes (e.g. §a, §l, §r) before matching.
_COLOR_CODE_RE = re.compile(r"§[0-9a-fk-orA-FK-OR]")

# A loose version token: digits with optional dots and trailing .x
# Accepts both standard "1.21.4" and non-standard display versions like "26.1"
_VER = r"\d+(?:\.\d+)*(?:\.x)?"

# Separator: hyphen/en-dash, or words "to" / "a" (Spanish) surrounded by spaces
_SEP = r"(?:\s*[-–]\s*|\s+(?:to|a)\s+)"

# Full range pattern: <version> <sep> <version>
# At least one side must start with "1." to anchor it to Minecraft versions,
# or allow the non-standard major on the right side (e.g. "1.8 a 26.1").
_RANGE_RE = re.compile(rf"1\.{_VER}{_SEP}{_VER}", re.IGNORECASE)


def _strip_color_codes(text: str) -> str:
    return _COLOR_CODE_RE.sub("", text)


def _is_multiversion(ping_motd: str | None, version_name: str | None) -> bool:
    """Return True if any text field signals a version-range proxy."""
    for raw in (ping_motd or "", version_name or ""):
        if _RANGE_RE.search(_strip_color_codes(raw)):
            return True
    return False


class OutdatedVersionCheck:
    check_id = "outdated-version"
    kind = "passive"
    title = "Outdated Server Version"
    description = "Compares protocol version against latest stable; ViaVersion-aware"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        protocol = result.ping.protocol_version
        if protocol is None or protocol < 0:
            return []

        if protocol >= LATEST_STABLE_PROTOCOL:
            return []

        if _is_multiversion(result.ping.motd, result.ping.version_name):
            return [
                Finding(
                    check_id=self.check_id,
                    title="Multi-Version Proxy Detected (ViaVersion/ViaBackwards)",
                    severity=Severity.INFO,
                    description=(
                        "The server advertises an old protocol version but shows a "
                        "version range in its MOTD or version string, indicating a "
                        "ViaVersion/ViaBackwards proxy. The underlying server software "
                        "version cannot be determined from the ping alone."
                    ),
                    evidence=(
                        f"Version string: {result.ping.version_name!r} | "
                        f"MOTD: {(result.ping.motd or '')[:80]!r}"
                    ),
                    remediation=(
                        "Verify the backend server version separately. Ensure ViaVersion "
                        "and ViaBackwards are up to date, as they carry their own CVEs."
                    ),
                )
            ]

        is_critical = protocol in CRITICALLY_VULNERABLE_PROTOCOLS
        severity = Severity.HIGH if is_critical else Severity.MEDIUM

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=severity,
                description=(
                    f"Server is running protocol version {protocol} "
                    f"({result.ping.version_name or 'unknown'}), "
                    f"which is older than the latest stable release "
                    f"{LATEST_STABLE_NAME} (protocol {LATEST_STABLE_PROTOCOL}). "
                    "Outdated servers miss security patches."
                ),
                evidence=(
                    f"Detected: {result.ping.version_name!r} (protocol {protocol}) | "
                    f"Latest: {LATEST_STABLE_NAME} (protocol {LATEST_STABLE_PROTOCOL})"
                ),
                remediation=(
                    f"Upgrade to Minecraft {LATEST_STABLE_NAME} or the latest "
                    "stable release. Review the changelog for patched CVEs."
                ),
            )
        ]
