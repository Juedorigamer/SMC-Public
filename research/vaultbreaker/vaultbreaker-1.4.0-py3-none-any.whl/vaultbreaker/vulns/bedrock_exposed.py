from __future__ import annotations

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity


class BedrockExposedCheck:
    check_id = "bedrock_exposed"
    kind = "probe"
    title = "Bedrock/GeyserMC Endpoint Publicly Exposed"
    description = "Detects a publicly accessible Bedrock server on UDP 19132"

    async def run(self, result: ScanResult) -> list[Finding]:
        bedrock = result.metadata.get("bedrock")
        if not bedrock:
            return []

        edition = bedrock.get("edition", "MCPE")
        version = bedrock.get("version", "unknown")
        players = bedrock.get("players_online", 0)
        players_max = bedrock.get("players_max", 0)
        gamemode = bedrock.get("gamemode", "unknown")

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=Severity.MEDIUM,
                confidence=Confidence.CONFIRMED,
                description=(
                    f"A Bedrock/{edition} server is publicly accessible on UDP port 19132. "
                    f"Version: {version}, Players: {players}/{players_max}, Gamemode: {gamemode}. "
                    "Without an allowlist, any Bedrock client (including GeyserMC users) can connect."
                ),
                evidence=(
                    f"Edition: {edition} | Version: {version} | "
                    f"Players: {players}/{players_max} | Gamemode: {gamemode}"
                ),
                remediation=(
                    "Configure an allowlist (allowlist.json) to restrict which players can join. "
                    "If using GeyserMC as a bridge, ensure the underlying Java server's allowlist is active."
                ),
            )
        ]
