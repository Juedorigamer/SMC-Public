from __future__ import annotations

from typing import Literal, Protocol, runtime_checkable

from vaultbreaker.core.models import Finding, ScanResult


@runtime_checkable
class VulnCheck(Protocol):
    check_id: str
    title: str
    kind: Literal["passive", "probe", "active"]
    description: str  # one-liner ≤80 chars for 'vaultbreaker checks' table

    async def run(self, result: ScanResult) -> list[Finding]:
        ...
