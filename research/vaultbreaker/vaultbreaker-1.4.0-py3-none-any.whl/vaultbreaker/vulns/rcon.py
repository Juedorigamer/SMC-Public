from __future__ import annotations

import asyncio
import contextlib

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

# RCON port check — passive TCP reachability only.
#
# We open a TCP connection to confirm the port is listening and immediately
# close it. We do NOT send any RCON protocol bytes, attempt authentication,
# or brute-force passwords. The mere fact that the port is open to the
# internet is the finding: RCON has no rate-limiting and a weak auth model.

RCON_PORT = 25575
_CONNECT_TIMEOUT = 3.0  # seconds


class RCONCheck:
    check_id = "rcon-exposed"
    kind = "active"
    title = "RCON Port Exposed to Internet (TCP 25575)"
    description = "TCP probe to port 25575 to detect internet-exposed RCON console access"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        host = result.target.host

        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection(host, RCON_PORT),
                timeout=_CONNECT_TIMEOUT,
            )
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()
        except (TimeoutError, OSError):
            return []

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=Severity.CRITICAL,
                confidence=Confidence.POSSIBLE,
                description=(
                    "TCP port 25575 is reachable from the internet. This port is "
                    "conventionally used for RCON, which grants full server console "
                    "access. Note: TCP connectivity alone does not confirm RCON is "
                    "active — the service behind this port may not respond to the "
                    "RCON protocol. If RCON is enabled, any operator command can be "
                    "run remotely and the password can be brute-forced offline."
                ),
                evidence=f"TCP connection to {host}:{RCON_PORT} succeeded",
                remediation=(
                    "1. Block TCP 25575 at the firewall/security-group level immediately.\n"
                    "2. If remote console access is required, use SSH tunnelling: "
                    "'ssh -L 25575:localhost:25575 user@server' and connect locally.\n"
                    "3. In server.properties set 'enable-rcon=false' unless actively needed.\n"
                    "4. If RCON must remain enabled, bind it to localhost only via "
                    "'rcon.ip=127.0.0.1' in server.properties."
                ),
            )
        ]
