from __future__ import annotations

from vaultbreaker.core.models import Finding, ScanResult, Severity


class QueryExposedCheck:
    check_id = "query-exposed"
    kind = "passive"
    title = "Query Protocol Exposed (enable-query=true)"
    description = "Detects enable-query=true exposing plugins, map name and internal IP"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.query or not result.query.online:
            return []

        evidence_parts = []
        if result.query.plugins:
            evidence_parts.append(f"Plugins leaked: {', '.join(result.query.plugins[:10])}")
        if result.query.map_name:
            evidence_parts.append(f"Map: {result.query.map_name}")
        if result.query.host_ip:
            evidence_parts.append(f"Host IP: {result.query.host_ip}")

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=Severity.MEDIUM,
                description=(
                    "The server has enable-query=true, exposing detailed metadata "
                    "via the UDP Query protocol including plugin names, map name, "
                    "and internal IP address. Attackers use this to fingerprint "
                    "vulnerable plugins without connecting."
                ),
                evidence=" | ".join(evidence_parts) if evidence_parts else "Query port responded",
                remediation=(
                    "Set enable-query=false in server.properties unless you "
                    "explicitly need server list integrations that require Query."
                ),
            )
        ]
