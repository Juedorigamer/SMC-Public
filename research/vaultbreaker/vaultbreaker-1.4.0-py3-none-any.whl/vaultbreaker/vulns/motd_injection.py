from __future__ import annotations

import re

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

# Patterns that indicate unescaped user-controlled content or suspicious formatting.
_SCRIPT_PATTERN = re.compile(r"<script|javascript:|on\w+=", re.IGNORECASE)
_EXCESSIVE_CODES = re.compile(r"(§[0-9a-fk-or]){6,}", re.IGNORECASE)
_NULL_BYTES = re.compile(r"\x00|\u0000")
_FORMAT_OVERFLOW = re.compile(r"§{10,}")


class MotdInjectionCheck:
    check_id = "motd-injection"
    title = "MOTD Injection / Formatting Abuse Detected"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        motd = result.ping.motd or ""
        evidence_parts: list[str] = []

        if _SCRIPT_PATTERN.search(motd):
            evidence_parts.append("script/HTML tag in MOTD")

        if _NULL_BYTES.search(motd):
            evidence_parts.append("null bytes in MOTD")

        if _EXCESSIVE_CODES.search(motd):
            evidence_parts.append("excessive formatting codes (possible injection)")

        if _FORMAT_OVERFLOW.search(motd):
            evidence_parts.append("formatting code overflow")

        if not evidence_parts:
            return []

        return [
            Finding(
                check_id=self.check_id,
                title=self.title,
                severity=Severity.LOW,
                confidence=Confidence.POSSIBLE,
                description=(
                    "The server MOTD contains patterns consistent with injection abuse or "
                    "formatting-code overflow. While Minecraft clients sanitize most rendering, "
                    "some third-party MOTD processors and bot clients may be vulnerable to "
                    "script injection or display corruption via malformed color codes."
                ),
                evidence=f"MOTD: {motd!r} | Indicators: {', '.join(evidence_parts)}",
                remediation=(
                    "Ensure the MOTD is set to a static string in server.properties. "
                    "If using a MOTD plugin, validate and escape all dynamic input. "
                    "Avoid processing MOTDs from untrusted servers in downstream tooling."
                ),
            )
        ]
