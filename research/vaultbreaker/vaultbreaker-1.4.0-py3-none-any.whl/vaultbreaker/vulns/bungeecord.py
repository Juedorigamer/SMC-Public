from __future__ import annotations

import re

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

# BungeeCord / Waterfall / Velocity — proxy detection and misconfiguration checks.
#
# Passive signals only:
#   1. Version string / MOTD fingerprinting → identify proxy software and version
#   2. backend_host from the Query response (only populated for some proxy builds)
#
# We deliberately do NOT attempt any authentication or login sequence.

_COLOR_CODE_RE = re.compile(r"§[0-9a-fk-orA-FK-OR]")

# Proxy fingerprints: (compiled-regex, canonical-name, safe-version-or-None)
# safe_version: the first version that closed the IP-forwarding auth bypass.
_PROXY_PATTERNS: list[tuple[re.Pattern[str], str, str | None]] = [
    (re.compile(r"\bvelocity\b", re.IGNORECASE), "Velocity", "3.1.1"),
    (re.compile(r"\bwaterfall\b", re.IGNORECASE), "Waterfall", None),
    (re.compile(r"\bbungee(?:cord)?\b", re.IGNORECASE), "BungeeCord", None),
]

# Velocity reports versions like "Velocity 3.2.0" or "3.2.0 (git-...)"
_VELOCITY_VERSION_RE = re.compile(r"velocity\s+(\d+\.\d+(?:\.\d+)?)", re.IGNORECASE)


def _strip(text: str) -> str:
    return _COLOR_CODE_RE.sub("", text)


def _detect_proxy(ping_motd: str | None, version_name: str | None) -> str | None:
    """Return the proxy name if fingerprinted, else None."""
    for raw in (ping_motd or "", version_name or ""):
        clean = _strip(raw)
        for pattern, name, _ in _PROXY_PATTERNS:
            if pattern.search(clean):
                return name
    return None


def _detect_velocity_version(version_name: str | None) -> str | None:
    m = _VELOCITY_VERSION_RE.search(version_name or "")
    return m.group(1) if m else None


class BungeeCordCheck:
    check_id = "bungeecord"
    kind = "passive"
    title = "Proxy Misconfiguration (BungeeCord / Waterfall / Velocity)"
    description = "Fingerprints proxy software and checks for IP-forwarding auth bypass"

    async def run(self, result: ScanResult) -> list[Finding]:
        if not result.ping or not result.ping.online:
            return []

        proxy_name = _detect_proxy(result.ping.motd, result.ping.version_name)
        if proxy_name is None:
            return []

        findings: list[Finding] = []

        # ── Finding 1: IP forwarding / authentication bypass ──────────────────
        if proxy_name == "Velocity":
            velocity_ver = _detect_velocity_version(result.ping.version_name)
            if velocity_ver:
                from packaging.version import InvalidVersion, Version

                try:
                    is_old = Version(velocity_ver) < Version("3.1.1")
                except InvalidVersion:
                    is_old = False
            else:
                # Version unknown — flag conservatively
                is_old = True

            if is_old:
                findings.append(
                    Finding(
                        check_id=self.check_id,
                        title="Velocity: Outdated Proxy Version (Possible Remote Code Execution)",
                        severity=Severity.CRITICAL,
                        confidence=Confidence.FINGERPRINT_ONLY,
                        description=(
                            "Older Velocity versions (before 3.1.1) had a known remote code "
                            "execution vector via a crafted client handshake packet that could "
                            "allow forging modern-forwarding secrets without authentication. "
                            "This finding is based on version fingerprinting only — verify the "
                            "exact build against the official Velocity security advisories."
                        ),
                        evidence=f"Detected Velocity version: {velocity_ver or 'unknown'}",
                        remediation=(
                            "Upgrade Velocity to the latest stable release. Enable 'modern' "
                            "forwarding mode in velocity.toml and set a strong forwarding-secret. "
                            "Review: https://github.com/PaperMC/Velocity/security/advisories"
                        ),
                    )
                )
            else:
                # Modern Velocity detected — note forwarding mode best practice
                findings.append(
                    Finding(
                        check_id=self.check_id,
                        title="Velocity Proxy Detected",
                        severity=Severity.INFO,
                        confidence=Confidence.LIKELY,
                        description=(
                            "A Velocity proxy was detected. Verify that 'modern' forwarding "
                            "mode is configured and that backend servers are firewalled from "
                            "direct internet access."
                        ),
                        evidence=f"Detected Velocity version: {velocity_ver or 'unknown'}",
                        remediation=(
                            "Ensure backend Minecraft servers bind only to localhost or a "
                            "private network interface. Use 'forwarding-secret' in velocity.toml "
                            "with modern forwarding. "
                            "See: https://docs.papermc.io/velocity/security"
                        ),
                    )
                )

        else:
            # BungeeCord or Waterfall — IP forwarding auth bypass
            findings.append(
                Finding(
                    check_id=self.check_id,
                    title=f"{proxy_name}: IP Forwarding Authentication Bypass",
                    severity=Severity.HIGH,
                    confidence=Confidence.LIKELY,
                    description=(
                        f"{proxy_name} relies on IP forwarding headers to pass player identity "
                        "to backend servers. If backend servers are directly reachable from the "
                        "internet (not firewalled), any client can spoof player UUIDs and "
                        "usernames, bypassing authentication entirely."
                    ),
                    evidence=(
                        f"Proxy software: {proxy_name} | "
                        f"Version: {result.ping.version_name!r}"
                    ),
                    remediation=(
                        f"1. Firewall all backend Minecraft servers so they are only reachable "
                        f"from the {proxy_name} proxy's private IP.\n"
                        "2. Enable 'bungeecord: true' in spigot.yml on each backend.\n"
                        "3. Consider migrating to Velocity with 'modern' forwarding, which "
                        "uses HMAC-signed tokens instead of header trust.\n"
                        "See: https://www.spigotmc.org/wiki/bungeecord-ip-forwarding/"
                    ),
                )
            )

        # ── Finding 2: Backend exposure via Query host_ip ─────────────────────
        if result.query and result.query.online and result.query.host_ip:
            host_ip = result.query.host_ip
            # Only flag if the query host_ip looks like a public/routable IP
            # (basic heuristic: not 127.x, 10.x, 172.16-31.x, 192.168.x)
            if not _is_private(host_ip):
                findings.append(
                    Finding(
                        check_id=self.check_id,
                        title="Backend Server Potentially Internet-Exposed",
                        severity=Severity.HIGH,
                        confidence=Confidence.POSSIBLE,
                        description=(
                            "The UDP Query response includes a host_ip that appears to be a "
                            "public address. If this is a backend server sitting behind the proxy, "
                            "direct connections to it would bypass the proxy's authentication and "
                            "IP forwarding protections."
                        ),
                        evidence=f"Query host_ip: {host_ip} | Proxy: {proxy_name}",
                        remediation=(
                            "Bind backend Minecraft server to a private/loopback interface only. "
                            "Use firewall rules (iptables, ufw, Windows Firewall) to block port "
                            "25565 from external access. Only the proxy's IP should reach backends."
                        ),
                    )
                )

        return findings


def _is_private(ip: str) -> bool:
    """Return True if ip is a private/loopback address (basic check, IPv4 only)."""
    parts = ip.split(".")
    if len(parts) != 4:
        return False
    try:
        a, b = int(parts[0]), int(parts[1])
    except ValueError:
        return False
    if a == 127:
        return True
    if a == 10:
        return True
    if a == 172 and 16 <= b <= 31:
        return True
    return a == 192 and b == 168
