from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

from vaultbreaker.core.models import Confidence, Finding, ScanResult, Severity

_TEMPLATES_DIR = Path(__file__).parent / "templates"

_CHECK_CATEGORY: dict[str, str] = {
    "log4shell": "Dependency / RCE",
    "plugin_cve": "Plugin / CVE",
    "rcon_exposed": "Configuration / Exposure",
    "bungeecord": "Proxy / Configuration",
    "cracked": "Authentication / Exposure",
    "query_exposed": "Information Disclosure",
    "outdated_version": "Configuration / Outdated",
    "dynmap": "Information Disclosure",
    "port_sweep": "Network / Exposure",
}

_CONFIDENCE_FLOAT: dict[Confidence, float] = {
    Confidence.CONFIRMED: 1.00,
    Confidence.LIKELY: 0.75,
    Confidence.POSSIBLE: 0.50,
    Confidence.FINGERPRINT_ONLY: 0.30,
}

_SEVERITY_DEFAULT_RISK: dict[Severity, float] = {
    Severity.CRITICAL: 9.5,
    Severity.HIGH: 7.5,
    Severity.MEDIUM: 5.0,
    Severity.LOW: 2.5,
    Severity.INFO: 1.0,
}

_SEVERITY_CVSS: dict[Severity, str] = {
    Severity.CRITICAL: "9.8",
    Severity.HIGH: "7.5",
    Severity.MEDIUM: "5.3",
    Severity.LOW: "2.6",
    Severity.INFO: "—",
}

_CVE_RE = re.compile(
    r"\b(CVE-\d{4}-\d{4,}|GHSA-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4})\b"
)


def _extract_cves(text: str) -> list[str]:
    return list(dict.fromkeys(_CVE_RE.findall(text)))


def _split_remediation(text: str | None) -> list[str]:
    if not text:
        return []
    steps = [s.strip() for s in re.split(r"\n+", text.strip()) if s.strip()]
    return [re.sub(r"^\d+\.\s*", "", s) for s in steps] or [text]


def _finding_to_js(finding: Finding, index: int, year: int) -> dict[str, Any]:
    risk = finding.ai_risk_score or _SEVERITY_DEFAULT_RISK[finding.severity]
    full_text = finding.title + " " + finding.description
    cves = _extract_cves(full_text)
    remediation_steps = _split_remediation(finding.ai_remediation or finding.remediation)
    evidence_blocks = (
        [{"lang": "text", "text": finding.evidence}] if finding.evidence else []
    )
    return {
        "id": f"VB-{year}-{index:04d}",
        "sev": finding.severity.value.lower(),
        "title": finding.title,
        "category": _CHECK_CATEGORY.get(finding.check_id, "General"),
        "cvss": _SEVERITY_CVSS[finding.severity],
        "confidence": _CONFIDENCE_FLOAT[finding.confidence],
        "risk": round(risk, 1),
        "affected": finding.evidence or "",
        "cve": cves,
        "tags": [finding.check_id.replace("_", "-")],
        "description": [finding.description] if finding.description else ["No description available."],
        "remediation": remediation_steps or ["No remediation available."],
        "evidence": evidence_blocks,
    }


def _compute_aggregate_risk(js_findings: list[dict[str, Any]]) -> tuple[float, str]:
    if not js_findings:
        return 0.0, "info"
    risks = sorted((f["risk"] for f in js_findings), reverse=True)
    total, weight_sum = 0.0, 0.0
    for i, r in enumerate(risks):
        w = 1.0 / (i + 1)
        total += r * w
        weight_sum += w
    score = round(total / weight_sum, 1) if weight_sum else 0.0
    if score >= 9.0:
        sev = "critical"
    elif score >= 7.0:
        sev = "high"
    elif score >= 4.0:
        sev = "medium"
    elif score >= 1.0:
        sev = "low"
    else:
        sev = "info"
    return score, sev


def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    secs = int(seconds)
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m:02d}m {s:02d}s"
    return f"{m}m {s:02d}s"


class ReportGenerator:
    def __init__(self) -> None:
        self._env = Environment(
            loader=FileSystemLoader(str(_TEMPLATES_DIR)),
            autoescape=select_autoescape(["html"]),
        )

    def generate(
        self,
        scan_result: ScanResult,
        *,
        client_name: str = "",
        engagement_tag: str = "",
        executive_summary: str | None = None,
    ) -> str:
        scanned_at = scan_result.scanned_at
        year = scanned_at.year

        js_findings = [
            _finding_to_js(f, i + 1, year)
            for i, f in enumerate(scan_result.findings_by_severity)
        ]

        risk_score, risk_sev = _compute_aggregate_risk(js_findings)
        risk_pct = max(3, round(risk_score * 10))

        report_seed = f"{scan_result.target.host}:{scanned_at.isoformat()}"
        report_id = "vb-" + hashlib.sha256(report_seed.encode()).hexdigest()[:6]

        effective_client = client_name or scan_result.target.host
        effective_summary = executive_summary if executive_summary is not None else scan_result.executive_summary

        template = self._env.get_template("report.html.j2")
        return template.render(
            target=scan_result.target.host,
            resolved_ip="—",
            scan_started=scanned_at.strftime("%Y-%m-%d %H:%M UTC"),
            duration=_format_duration(scan_result.duration_s),
            tool_version="0.1.0",
            report_id=report_id,
            client_name=effective_client,
            engagement_tag=engagement_tag,
            executive_summary=effective_summary,
            risk_score=risk_score,
            risk_pct=risk_pct,
            risk_label=risk_sev.capitalize(),
            risk_sev=risk_sev,
            total_findings=len(js_findings),
            findings_json=json.dumps(js_findings, ensure_ascii=False, indent=2),
            year=year,
            tweaks_defaults_json=json.dumps({
                "client_name": effective_client,
                "engagement_tag": engagement_tag,
                "show_ai": True,
                "palette": "default",
            }),
        )

    def save(
        self,
        scan_result: ScanResult,
        output_path: Path,
        *,
        client_name: str = "",
        engagement_tag: str = "",
        executive_summary: str | None = None,
    ) -> None:
        html = self.generate(
            scan_result,
            client_name=client_name,
            engagement_tag=engagement_tag,
            executive_summary=executive_summary,
        )
        output_path.write_text(html, encoding="utf-8")


def generate_aggregate_report(results: list[ScanResult], output_dir: Path) -> Path:
    """Generate an HTML index + per-target sub-reports for a batch scan."""
    from vaultbreaker.constants import VERSION

    timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    report_dir = output_dir / f"report-{timestamp}"
    report_dir.mkdir(parents=True, exist_ok=True)

    generator = ReportGenerator()

    _sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}

    rows: list[dict[str, Any]] = []
    total_findings = 0
    critical_count = 0
    high_count = 0
    medium_count = 0
    all_risk_scores: list[float] = []

    for result in results:
        host_slug = result.target.host.replace(":", "_").replace("/", "_")
        sub_name = f"{host_slug}-report.html"
        sub_path = report_dir / sub_name
        generator.save(result, sub_path)

        counts: dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for f in result.findings:
            counts[f.severity.value] += 1

        highest_sev = "info"
        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
            if counts[sev] > 0:
                highest_sev = sev.lower()
                break

        js_findings = [
            _finding_to_js(f, i + 1, result.scanned_at.year)
            for i, f in enumerate(result.findings_by_severity)
        ]
        risk_score, _ = _compute_aggregate_risk(js_findings)
        if js_findings:
            all_risk_scores.append(risk_score)

        total_findings += len(result.findings)
        critical_count += counts["CRITICAL"]
        high_count += counts["HIGH"]
        medium_count += counts["MEDIUM"]

        rows.append({
            "host": result.target.address,
            "total": len(result.findings),
            "critical": counts["CRITICAL"],
            "high": counts["HIGH"],
            "medium": counts["MEDIUM"],
            "low": counts["LOW"],
            "info": counts["INFO"],
            "highest_sev": highest_sev,
            "report_link": sub_name,
        })

    avg_risk = round(sum(all_risk_scores) / len(all_risk_scores), 1) if all_risk_scores else 0.0
    _, avg_risk_sev = _compute_aggregate_risk(
        [{"risk": avg_risk}] if avg_risk > 0 else []
    )

    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATES_DIR)),
        autoescape=select_autoescape(["html"]),
    )
    template = env.get_template("report_aggregate.html.j2")
    index_html = template.render(
        scan_date=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        tool_version=VERSION,
        results=results,
        rows=rows,
        total_findings=total_findings,
        critical_count=critical_count,
        high_count=high_count,
        medium_count=medium_count,
        avg_risk_score=avg_risk,
        avg_risk_sev=avg_risk_sev,
    )

    index_path = report_dir / "index.html"
    index_path.write_text(index_html, encoding="utf-8")
    return index_path
