from __future__ import annotations

import json
from pathlib import Path

from vaultbreaker.core.models import ScanResult


class JsonReporter:
    def save(self, scan_result: ScanResult, output_path: Path) -> None:
        data = scan_result.model_dump(mode="json")
        output_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
