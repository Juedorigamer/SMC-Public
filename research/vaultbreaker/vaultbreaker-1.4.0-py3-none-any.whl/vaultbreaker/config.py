from __future__ import annotations

import os
import tomllib
from pathlib import Path
from typing import Any, Literal

from platformdirs import user_config_dir
from pydantic_settings import BaseSettings, SettingsConfigDict


def get_config_path() -> Path:
    """Return the path to the user's config.toml (may not exist)."""
    return Path(user_config_dir("vaultbreaker", appauthor=False)) / "config.toml"


KNOWN_KEYS: dict[str, type] = {
    "default_port": int,
    "default_timeout": float,
    "default_rate": float,
    "ollama_url": str,
    "ollama_model": str,
    "debug": bool,
    "ai_enabled": bool,
    "report_auto_open": bool,
    "ethics_level": str,
    "max_concurrent": int,
}


def _load_toml() -> dict[str, Any]:
    """Load TOML config file. Returns empty dict if file doesn't exist."""
    path = get_config_path()
    if not path.exists():
        return {}
    try:
        with path.open("rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def _write_toml(data: dict[str, Any]) -> None:
    """Write config dict to TOML file, creating parent dirs as needed."""
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    for k, v in sorted(data.items()):
        if isinstance(v, bool):
            lines.append(f"{k} = {str(v).lower()}")
        elif isinstance(v, str):
            escaped = v.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k} = "{escaped}"')
        elif isinstance(v, (int, float)):
            lines.append(f"{k} = {v}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def load_with_sources() -> dict[str, tuple[Any, Literal["env", "toml", "default"]]]:
    """Return {key: (value, source)} for all known config keys.

    Source is determined by the highest-priority source that has the key:
      env > toml > default
    """
    toml_data = _load_toml()
    result: dict[str, tuple[Any, Literal["env", "toml", "default"]]] = {}

    for key in KNOWN_KEYS:
        env_var = f"VAULTBREAKER_{key.upper()}"
        if env_var in os.environ:
            source: Literal["env", "toml", "default"] = "env"
        elif key in toml_data:
            source = "toml"
        else:
            source = "default"
        value = getattr(settings, key, None)
        result[key] = (value, source)

    return result


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="VAULTBREAKER_", env_file=".env")

    default_port: int = 25565
    default_timeout: float = 5.0
    default_rate: float = 2.0
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:3b"
    debug: bool = False
    ai_enabled: bool = True
    report_auto_open: bool = True
    ethics_level: str = "probe"
    max_concurrent: int = 4


def _make_settings() -> Settings:
    """Build Settings, merging TOML values under env vars."""
    toml_data = _load_toml()
    # Only pass TOML values that are not already set via env
    toml_init: dict[str, Any] = {}
    for key, value in toml_data.items():
        if key in KNOWN_KEYS:
            env_var = f"VAULTBREAKER_{key.upper()}"
            if env_var not in os.environ:
                toml_init[key] = value
    return Settings(**toml_init)


settings = _make_settings()
